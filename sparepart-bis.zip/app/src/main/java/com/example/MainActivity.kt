package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.SparePart
import com.example.ui.dialogs.AddEditBusDialog
import com.example.ui.dialogs.AddEditSparePartDialog
import com.example.ui.dialogs.AdjustStockDialog
import com.example.ui.dialogs.InstallPartDialog
import com.example.ui.dialogs.PartDetailDialog
import com.example.ui.dialogs.ReplacePartDialog
import com.example.ui.dialogs.UpdateOdometerDialog
import com.example.ui.screens.BarcodeScanScreen
import com.example.ui.screens.BusDetailScreen
import com.example.ui.screens.BusFleetScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MaintenanceHistoryScreen
import com.example.ui.screens.SparePartsScreen
import com.example.ui.theme.SparepartBisTheme
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SparepartBisTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val title: String,
    val icon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(viewModel: MainViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val selectedBusId by viewModel.selectedBusId.collectAsStateWithLifecycle()
    val selectedPartDetail by viewModel.selectedSparePart.collectAsStateWithLifecycle()

    val allParts by viewModel.allSpareParts.collectAsStateWithLifecycle()
    val allBuses by viewModel.allBuses.collectAsStateWithLifecycle()
    val allInstalled by viewModel.allActiveInstalledParts.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Listen to user messages/snackbars
    LaunchedEffect(Unit) {
        viewModel.userMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Dialog States
    var showAddPartDialog by remember { mutableStateOf(false) }
    var partToEdit by remember { mutableStateOf<SparePart?>(null) }
    var initialBarcodeForNewPart by remember { mutableStateOf("") }

    var showAddBusDialog by remember { mutableStateOf(false) }
    var busToEdit by remember { mutableStateOf<BusUnit?>(null) }

    var showInstallDialog by remember { mutableStateOf(false) }
    var installTargetBus by remember { mutableStateOf<BusUnit?>(null) }
    var installSelectedPart by remember { mutableStateOf<SparePart?>(null) }

    var showReplaceDialog by remember { mutableStateOf(false) }
    var replaceTargetInstalledPart by remember { mutableStateOf<InstalledPart?>(null) }
    var replaceTargetBus by remember { mutableStateOf<BusUnit?>(null) }

    var showAdjustStockDialog by remember { mutableStateOf(false) }
    var stockAdjustPart by remember { mutableStateOf<SparePart?>(null) }

    var showUpdateOdoDialog by remember { mutableStateOf(false) }
    var odoTargetBus by remember { mutableStateOf<BusUnit?>(null) }

    // Handle back gesture when in Bus Detail
    BackHandler(enabled = selectedBusId != null) {
        viewModel.closeBusDetail()
    }

    val navItems = listOf(
        NavItem("Beranda", Icons.Default.Dashboard, "nav_dashboard"),
        NavItem("Sparepart", Icons.Default.Inventory2, "nav_spareparts"),
        NavItem("Armada", Icons.Default.DirectionsBus, "nav_buses"),
        NavItem("Scan Barcode", Icons.Default.QrCodeScanner, "nav_scan"),
        NavItem("Riwayat", Icons.Default.History, "nav_history")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (selectedBusId == null) {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF49454F)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DirectionsBus,
                                    contentDescription = null,
                                    tint = Color(0xFFD0BCFF),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Sparepart Bis",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color(0xFFE6E1E5)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color(0xFF1C1B1F),
                        titleContentColor = Color(0xFFE6E1E5)
                    )
                )
            }
        },
        bottomBar = {
            if (selectedBusId == null) {
                Surface(
                    color = Color(0xFF2B2930),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    NavigationBar(
                        containerColor = Color(0xFF2B2930),
                        tonalElevation = 0.dp
                    ) {
                        navItems.forEachIndexed { index, item ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { viewModel.setTab(index) },
                                icon = {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.title
                                    )
                                },
                                label = {
                                    Text(
                                        item.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color(0xFFD0BCFF),
                                    selectedTextColor = Color(0xFFD0BCFF),
                                    indicatorColor = Color(0xFF4A4458),
                                    unselectedIconColor = Color(0xFFCAC4D0),
                                    unselectedTextColor = Color(0xFFCAC4D0)
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (selectedBusId != null) {
                // Bus Detail View
                BusDetailScreen(
                    viewModel = viewModel,
                    onBackClick = { viewModel.closeBusDetail() },
                    onInstallPartClick = { bus ->
                        installTargetBus = bus
                        installSelectedPart = null
                        showInstallDialog = true
                    },
                    onReplacePartClick = { installed, bus ->
                        replaceTargetInstalledPart = installed
                        replaceTargetBus = bus
                        showReplaceDialog = true
                    },
                    onEditBusClick = { bus ->
                        busToEdit = bus
                        showAddBusDialog = true
                    },
                    onUpdateOdoClick = { bus ->
                        odoTargetBus = bus
                        showUpdateOdoDialog = true
                    },
                    onScanForThisBus = { bus ->
                        installTargetBus = bus
                        viewModel.setTab(3) // Switch to scan tab
                        viewModel.closeBusDetail()
                    }
                )
            } else {
                when (selectedTab) {
                    0 -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToScan = { viewModel.setTab(3) },
                        onNavigateToParts = { viewModel.setTab(1) },
                        onNavigateToBuses = { viewModel.setTab(2) },
                        onOpenBusDetail = { busId -> viewModel.openBusDetail(busId) },
                        onAddPartClick = {
                            partToEdit = null
                            initialBarcodeForNewPart = ""
                            showAddPartDialog = true
                        },
                        onAddBusClick = {
                            busToEdit = null
                            showAddBusDialog = true
                        }
                    )
                    1 -> SparePartsScreen(
                        viewModel = viewModel,
                        onAddPartClick = {
                            partToEdit = null
                            initialBarcodeForNewPart = ""
                            showAddPartDialog = true
                        },
                        onEditPartClick = { part ->
                            partToEdit = part
                            showAddPartDialog = true
                        },
                        onAdjustStockClick = { part ->
                            stockAdjustPart = part
                            showAdjustStockDialog = true
                        },
                        onSelectPart = { part ->
                            viewModel.selectSparePart(part)
                        },
                        onTestScan = { barcode ->
                            viewModel.onBarcodeScanned(barcode)
                            viewModel.setTab(3)
                        }
                    )
                    2 -> BusFleetScreen(
                        viewModel = viewModel,
                        onBusClick = { busId -> viewModel.openBusDetail(busId) },
                        onAddBusClick = {
                            busToEdit = null
                            showAddBusDialog = true
                        }
                    )
                    3 -> BarcodeScanScreen(
                        viewModel = viewModel,
                        onInstallScannedPartToBus = { part ->
                            installSelectedPart = part
                            installTargetBus = null
                            showInstallDialog = true
                        },
                        onAdjustScannedStock = { part ->
                            stockAdjustPart = part
                            showAdjustStockDialog = true
                        },
                        onViewScannedDetail = { part ->
                            viewModel.selectSparePart(part)
                        },
                        onAddNewPartWithBarcode = { barcode ->
                            partToEdit = null
                            initialBarcodeForNewPart = barcode
                            showAddPartDialog = true
                        }
                    )
                    4 -> MaintenanceHistoryScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // --- Dialogs ---

    // 1. Add / Edit Spare Part
    if (showAddPartDialog) {
        AddEditSparePartDialog(
            initialPart = partToEdit,
            initialBarcode = initialBarcodeForNewPart,
            onDismiss = { showAddPartDialog = false },
            onSave = { part ->
                viewModel.saveSparePart(part)
                showAddPartDialog = false
            }
        )
    }

    // 2. Add / Edit Bus Unit
    if (showAddBusDialog) {
        AddEditBusDialog(
            initialBus = busToEdit,
            onDismiss = { showAddBusDialog = false },
            onSave = { bus ->
                viewModel.saveBus(bus)
                showAddBusDialog = false
            }
        )
    }

    // 3. Install Part Dialog
    if (showInstallDialog) {
        InstallPartDialog(
            preselectedBus = installTargetBus,
            preselectedPart = installSelectedPart,
            allBuses = allBuses,
            allParts = allParts,
            onDismiss = { showInstallDialog = false },
            onConfirm = { bus, part, quantity, position, technician, targetInterval, notes ->
                viewModel.installPartToBus(
                    bus = bus,
                    part = part,
                    quantity = quantity,
                    position = position,
                    technician = technician,
                    targetIntervalKm = targetInterval,
                    notes = notes
                )
                showInstallDialog = false
            }
        )
    }

    // 4. Replace Part Dialog
    if (showReplaceDialog && replaceTargetInstalledPart != null && replaceTargetBus != null) {
        ReplacePartDialog(
            installedPart = replaceTargetInstalledPart!!,
            bus = replaceTargetBus!!,
            allParts = allParts,
            onDismiss = { showReplaceDialog = false },
            onConfirm = { oldInstalled, bus, newPart, qty, pos, tech, targetKm, notes ->
                viewModel.replaceInstalledPart(
                    oldInstalledPart = oldInstalled,
                    bus = bus,
                    newPart = newPart,
                    quantity = qty,
                    position = pos,
                    technician = tech,
                    targetIntervalKm = targetKm,
                    notes = notes
                )
                showReplaceDialog = false
            }
        )
    }

    // 5. Adjust Stock Dialog
    if (showAdjustStockDialog && stockAdjustPart != null) {
        AdjustStockDialog(
            part = stockAdjustPart!!,
            onDismiss = { showAdjustStockDialog = false },
            onConfirm = { delta, reason ->
                viewModel.quickAdjustStock(stockAdjustPart!!, delta, reason)
                showAdjustStockDialog = false
            }
        )
    }

    // 6. Update Odometer Dialog
    if (showUpdateOdoDialog && odoTargetBus != null) {
        UpdateOdometerDialog(
            bus = odoTargetBus!!,
            onDismiss = { showUpdateOdoDialog = false },
            onConfirm = { newOdo ->
                viewModel.updateBusOdometer(odoTargetBus!!.id, newOdo)
                showUpdateOdoDialog = false
            }
        )
    }

    // 7. Part Detail Dialog
    if (selectedPartDetail != null) {
        PartDetailDialog(
            part = selectedPartDetail!!,
            allBuses = allBuses,
            installedParts = allInstalled,
            onDismiss = { viewModel.selectSparePart(null) },
            onEdit = {
                partToEdit = selectedPartDetail
                viewModel.selectSparePart(null)
                showAddPartDialog = true
            },
            onDelete = {
                viewModel.deleteSparePart(selectedPartDetail!!)
            },
            onAdjustStock = {
                stockAdjustPart = selectedPartDetail
                showAdjustStockDialog = true
            },
            onInstallToBus = {
                installSelectedPart = selectedPartDetail
                installTargetBus = null
                showInstallDialog = true
            },
            onTestScan = { barcode ->
                viewModel.selectSparePart(null)
                viewModel.onBarcodeScanned(barcode)
                viewModel.setTab(3)
            }
        )
    }
}
