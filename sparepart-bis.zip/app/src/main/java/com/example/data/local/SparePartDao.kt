package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SparePart
import kotlinx.coroutines.flow.Flow

@Dao
interface SparePartDao {
    @Query("SELECT * FROM spare_parts ORDER BY name ASC")
    fun getAllParts(): Flow<List<SparePart>>

    @Query("SELECT * FROM spare_parts WHERE id = :id")
    suspend fun getPartById(id: Long): SparePart?

    @Query("SELECT * FROM spare_parts WHERE barcode = :barcode LIMIT 1")
    suspend fun getPartByBarcode(barcode: String): SparePart?

    @Query("SELECT * FROM spare_parts WHERE barcode = :query OR sku LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%'")
    fun searchParts(query: String): Flow<List<SparePart>>

    @Query("SELECT * FROM spare_parts WHERE category = :category ORDER BY name ASC")
    fun getPartsByCategory(category: String): Flow<List<SparePart>>

    @Query("SELECT * FROM spare_parts WHERE stockQuantity <= minStockThreshold")
    fun getLowStockParts(): Flow<List<SparePart>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPart(part: SparePart): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParts(parts: List<SparePart>)

    @Update
    suspend fun updatePart(part: SparePart)

    @Query("UPDATE spare_parts SET stockQuantity = stockQuantity + :amount WHERE id = :id")
    suspend fun updateStock(id: Long, amount: Int)

    @Delete
    suspend fun deletePart(part: SparePart)

    @Query("DELETE FROM spare_parts WHERE id = :id")
    suspend fun deletePartById(id: Long)

    @Query("SELECT COUNT(*) FROM spare_parts")
    fun getTotalPartsCount(): Flow<Int>
}
