package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.InstalledPart
import kotlinx.coroutines.flow.Flow

@Dao
interface InstalledPartDao {
    @Query("SELECT * FROM installed_parts WHERE busId = :busId AND isActive = 1 ORDER BY installedDate DESC")
    fun getActivePartsForBus(busId: Long): Flow<List<InstalledPart>>

    @Query("SELECT * FROM installed_parts WHERE busId = :busId ORDER BY installedDate DESC")
    fun getAllPartsForBus(busId: Long): Flow<List<InstalledPart>>

    @Query("SELECT * FROM installed_parts WHERE sparePartId = :sparePartId AND isActive = 1")
    fun getBusesUsingPart(sparePartId: Long): Flow<List<InstalledPart>>

    @Query("SELECT * FROM installed_parts WHERE id = :id")
    suspend fun getInstalledPartById(id: Long): InstalledPart?

    @Query("SELECT * FROM installed_parts WHERE isActive = 1")
    fun getAllActiveInstalledParts(): Flow<List<InstalledPart>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstalledPart(installedPart: InstalledPart): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInstalledParts(installedParts: List<InstalledPart>)

    @Update
    suspend fun updateInstalledPart(installedPart: InstalledPart)

    @Query("UPDATE installed_parts SET isActive = 0 WHERE id = :id")
    suspend fun markPartUninstalled(id: Long)

    @Query("UPDATE installed_parts SET conditionStatus = :condition WHERE id = :id")
    suspend fun updatePartCondition(id: Long, condition: String)

    @Delete
    suspend fun deleteInstalledPart(installedPart: InstalledPart)

    @Query("SELECT COUNT(*) FROM installed_parts WHERE isActive = 1")
    fun getTotalActiveInstalledCount(): Flow<Int>
}
