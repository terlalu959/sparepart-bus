package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bus_units")
data class BusUnit(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fleetNumber: String, // e.g. "BUS-01", "BUS-02"
    val plateNumber: String, // e.g. "B 7234 TGA"
    val busName: String, // e.g. "Executive Jetbus 3+ Voyager"
    val chassisModel: String, // e.g. "Hino RK8JSKA-NHJ R260"
    val year: Int = 2022,
    val route: String = "Jakarta - Surabaya",
    val currentOdometer: Int = 120000, // KM
    val operationalStatus: String = "Beroperasi", // Beroperasi, Dalam Perawatan, Perbaikan, Standby
    val driverName: String = "Pak Supir & Tim",
    val lastServiceDate: Long = System.currentTimeMillis(),
    val notes: String = ""
)
