package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "spare_parts")
data class SparePart(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sku: String,
    val barcode: String,
    val name: String,
    val category: String, // Mesin, Pengereman, Suspensi, Kelistrikan, Pelumas, Filter, Transmisi, Body
    val brand: String,
    val stockQuantity: Int,
    val minStockThreshold: Int = 5,
    val unit: String = "Pcs", // Pcs, Set, Liter, Box
    val rackLocation: String = "Gudang Utama",
    val price: Double = 0.0,
    val specifications: String = "",
    val compatibleBusModels: String = "Semua Tipe Bus",
    val createdAt: Long = System.currentTimeMillis()
)
