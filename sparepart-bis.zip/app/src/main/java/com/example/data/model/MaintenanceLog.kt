package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "maintenance_logs")
data class MaintenanceLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val busId: Long? = null,
    val sparePartId: Long? = null,
    val actionType: String, // "PEMASANGAN", "PENGGANTIAN", "PELEPASAN", "RESTOCK", "PENYESUAIAN"
    val busFleetNumber: String = "-",
    val busPlateNumber: String = "-",
    val partName: String,
    val partBarcode: String = "-",
    val quantity: Int = 1,
    val odometer: Int = 0,
    val technicianName: String = "Mekanik Pool",
    val date: Long = System.currentTimeMillis(),
    val notes: String = ""
)
