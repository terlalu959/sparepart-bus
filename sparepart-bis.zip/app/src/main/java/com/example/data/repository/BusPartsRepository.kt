package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.BusUnitDao
import com.example.data.local.DatabaseSeeder
import com.example.data.local.InstalledPartDao
import com.example.data.local.MaintenanceLogDao
import com.example.data.local.SparePartDao
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.MaintenanceLog
import com.example.data.model.SparePart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class BusPartsRepository(private val database: AppDatabase) {

    private val sparePartDao: SparePartDao = database.sparePartDao()
    private val busUnitDao: BusUnitDao = database.busUnitDao()
    private val installedPartDao: InstalledPartDao = database.installedPartDao()
    private val maintenanceLogDao: MaintenanceLogDao = database.maintenanceLogDao()

    val allSpareParts: Flow<List<SparePart>> = sparePartDao.getAllParts()
    val allBuses: Flow<List<BusUnit>> = busUnitDao.getAllBuses()
    val allLogs: Flow<List<MaintenanceLog>> = maintenanceLogDao.getAllLogs()
    val allActiveInstalledParts: Flow<List<InstalledPart>> = installedPartDao.getAllActiveInstalledParts()
    val lowStockParts: Flow<List<SparePart>> = sparePartDao.getLowStockParts()

    suspend fun checkAndSeedInitialDataIfNeeded() {
        withContext(Dispatchers.IO) {
            val partsCount = sparePartDao.getTotalPartsCount().first()
            val busesCount = busUnitDao.getTotalBusesCount().first()
            if (partsCount == 0 && busesCount == 0) {
                DatabaseSeeder.seedDatabase(database)
            }
        }
    }

    fun getInstalledPartsForBus(busId: Long): Flow<List<InstalledPart>> {
        return installedPartDao.getActivePartsForBus(busId)
    }

    fun getAllPartsForBusHistory(busId: Long): Flow<List<InstalledPart>> {
        return installedPartDao.getAllPartsForBus(busId)
    }

    fun getLogsForBus(busId: Long): Flow<List<MaintenanceLog>> {
        return maintenanceLogDao.getLogsForBus(busId)
    }

    fun getBusesUsingPart(sparePartId: Long): Flow<List<InstalledPart>> {
        return installedPartDao.getBusesUsingPart(sparePartId)
    }

    fun getBusByIdFlow(busId: Long): Flow<BusUnit?> {
        return busUnitDao.getBusByIdFlow(busId)
    }

    suspend fun getPartByBarcode(barcode: String): SparePart? = withContext(Dispatchers.IO) {
        sparePartDao.getPartByBarcode(barcode.trim())
    }

    suspend fun getPartById(id: Long): SparePart? = withContext(Dispatchers.IO) {
        sparePartDao.getPartById(id)
    }

    suspend fun getBusById(id: Long): BusUnit? = withContext(Dispatchers.IO) {
        busUnitDao.getBusById(id)
    }

    suspend fun insertOrUpdateSparePart(part: SparePart): Long = withContext(Dispatchers.IO) {
        if (part.id == 0L) {
            sparePartDao.insertPart(part)
        } else {
            sparePartDao.updatePart(part)
            part.id
        }
    }

    suspend fun deleteSparePart(part: SparePart) = withContext(Dispatchers.IO) {
        sparePartDao.deletePart(part)
    }

    suspend fun insertOrUpdateBus(bus: BusUnit): Long = withContext(Dispatchers.IO) {
        if (bus.id == 0L) {
            busUnitDao.insertBus(bus)
        } else {
            busUnitDao.updateBus(bus)
            bus.id
        }
    }

    suspend fun deleteBus(bus: BusUnit) = withContext(Dispatchers.IO) {
        busUnitDao.deleteBus(bus)
    }

    suspend fun updateBusOdometer(busId: Long, newOdo: Int) = withContext(Dispatchers.IO) {
        busUnitDao.updateOdometer(busId, newOdo, System.currentTimeMillis())
    }

    suspend fun updateBusStatus(busId: Long, status: String) = withContext(Dispatchers.IO) {
        busUnitDao.updateStatus(busId, status)
    }

    suspend fun installPartToBus(
        bus: BusUnit,
        part: SparePart,
        quantity: Int,
        position: String,
        technician: String,
        targetIntervalKm: Int,
        notes: String
    ): Result<InstalledPart> = withContext(Dispatchers.IO) {
        if (part.stockQuantity < quantity) {
            return@withContext Result.failure(Exception("Stok tidak mencukupi! Tersisa ${part.stockQuantity} ${part.unit}"))
        }

        // 1. Kurangi stok sparepart di gudang
        sparePartDao.updateStock(part.id, -quantity)

        // 2. Buat entitas InstalledPart
        val installedPart = InstalledPart(
            busId = bus.id,
            sparePartId = part.id,
            partName = part.name,
            partSku = part.sku,
            partBarcode = part.barcode,
            partCategory = part.category,
            installedDate = System.currentTimeMillis(),
            installedOdometer = bus.currentOdometer,
            targetOdometerInterval = targetIntervalKm,
            quantityInstalled = quantity,
            technicianName = technician.ifBlank { "Mekanik Pool Utama" },
            installationPosition = position.ifBlank { "Komponen Utama" },
            conditionStatus = "Bagus / Prima",
            isActive = true,
            notes = notes
        )
        val installedId = installedPartDao.insertInstalledPart(installedPart)

        // 3. Catat ke MaintenanceLog
        val log = MaintenanceLog(
            busId = bus.id,
            sparePartId = part.id,
            actionType = "PEMASANGAN",
            busFleetNumber = bus.fleetNumber,
            busPlateNumber = bus.plateNumber,
            partName = part.name,
            partBarcode = part.barcode,
            quantity = quantity,
            odometer = bus.currentOdometer,
            technicianName = technician.ifBlank { "Mekanik Pool Utama" },
            date = System.currentTimeMillis(),
            notes = "Pemasangan di $position. $notes"
        )
        maintenanceLogDao.insertLog(log)

        // 4. Update status dan tanggal servis bus
        busUnitDao.updateOdometer(bus.id, bus.currentOdometer, System.currentTimeMillis())

        return@withContext Result.success(installedPart.copy(id = installedId))
    }

    suspend fun replaceInstalledPart(
        oldInstalledPart: InstalledPart,
        bus: BusUnit,
        newPart: SparePart,
        quantity: Int,
        position: String,
        technician: String,
        targetIntervalKm: Int,
        notes: String
    ): Result<InstalledPart> = withContext(Dispatchers.IO) {
        if (newPart.stockQuantity < quantity) {
            return@withContext Result.failure(Exception("Stok part pengganti tidak cukup! Tersisa ${newPart.stockQuantity} ${newPart.unit}"))
        }

        // 1. Nonaktifkan part lama
        installedPartDao.markPartUninstalled(oldInstalledPart.id)

        // 2. Kurangi stok part baru
        sparePartDao.updateStock(newPart.id, -quantity)

        // 3. Tambahkan entitas baru
        val newInstalled = InstalledPart(
            busId = bus.id,
            sparePartId = newPart.id,
            partName = newPart.name,
            partSku = newPart.sku,
            partBarcode = newPart.barcode,
            partCategory = newPart.category,
            installedDate = System.currentTimeMillis(),
            installedOdometer = bus.currentOdometer,
            targetOdometerInterval = targetIntervalKm,
            quantityInstalled = quantity,
            technicianName = technician.ifBlank { "Mekanik Pool" },
            installationPosition = position.ifBlank { oldInstalledPart.installationPosition },
            conditionStatus = "Bagus / Prima",
            isActive = true,
            notes = "Mengganti: ${oldInstalledPart.partName}. $notes"
        )
        val newId = installedPartDao.insertInstalledPart(newInstalled)

        // 4. Catat Log Penggantian
        val log = MaintenanceLog(
            busId = bus.id,
            sparePartId = newPart.id,
            actionType = "PENGGANTIAN",
            busFleetNumber = bus.fleetNumber,
            busPlateNumber = bus.plateNumber,
            partName = "${newPart.name} (Ganti ${oldInstalledPart.partName})",
            partBarcode = newPart.barcode,
            quantity = quantity,
            odometer = bus.currentOdometer,
            technicianName = technician.ifBlank { "Mekanik Pool" },
            date = System.currentTimeMillis(),
            notes = "Penggantian komponen di posisi $position. $notes"
        )
        maintenanceLogDao.insertLog(log)

        return@withContext Result.success(newInstalled.copy(id = newId))
    }

    suspend fun uninstallPart(
        installedPart: InstalledPart,
        bus: BusUnit,
        returnStock: Boolean,
        technician: String,
        notes: String
    ) = withContext(Dispatchers.IO) {
        installedPartDao.markPartUninstalled(installedPart.id)
        if (returnStock) {
            sparePartDao.updateStock(installedPart.sparePartId, installedPart.quantityInstalled)
        }
        val log = MaintenanceLog(
            busId = bus.id,
            sparePartId = installedPart.sparePartId,
            actionType = "PELEPASAN",
            busFleetNumber = bus.fleetNumber,
            busPlateNumber = bus.plateNumber,
            partName = installedPart.partName,
            partBarcode = installedPart.partBarcode,
            quantity = installedPart.quantityInstalled,
            odometer = bus.currentOdometer,
            technicianName = technician.ifBlank { "Mekanik Pool" },
            date = System.currentTimeMillis(),
            notes = "Pelepasan part ${if (returnStock) "(Stok dikembalikan ke gudang)" else "(Part diafkir/rusak)"}. $notes"
        )
        maintenanceLogDao.insertLog(log)
    }

    suspend fun updateInstalledPartCondition(
        installedPartId: Long,
        newCondition: String
    ) = withContext(Dispatchers.IO) {
        installedPartDao.updatePartCondition(installedPartId, newCondition)
    }

    suspend fun quickAdjustStock(
        part: SparePart,
        delta: Int,
        reason: String
    ) = withContext(Dispatchers.IO) {
        sparePartDao.updateStock(part.id, delta)
        val log = MaintenanceLog(
            busId = null,
            sparePartId = part.id,
            actionType = if (delta > 0) "RESTOCK" else "PENYESUAIAN",
            busFleetNumber = "-",
            busPlateNumber = "-",
            partName = part.name,
            partBarcode = part.barcode,
            quantity = delta,
            odometer = 0,
            technicianName = "Petugas Gudang",
            date = System.currentTimeMillis(),
            notes = "Penyesuaian stok (${if (delta > 0) "+$delta" else "$delta"} ${part.unit}). Alasan: $reason"
        )
        maintenanceLogDao.insertLog(log)
    }
}
