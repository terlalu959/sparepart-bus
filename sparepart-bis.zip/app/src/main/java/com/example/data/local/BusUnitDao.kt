package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BusUnit
import kotlinx.coroutines.flow.Flow

@Dao
interface BusUnitDao {
    @Query("SELECT * FROM bus_units ORDER BY fleetNumber ASC")
    fun getAllBuses(): Flow<List<BusUnit>>

    @Query("SELECT * FROM bus_units WHERE id = :id")
    suspend fun getBusById(id: Long): BusUnit?

    @Query("SELECT * FROM bus_units WHERE id = :id")
    fun getBusByIdFlow(id: Long): Flow<BusUnit?>

    @Query("SELECT * FROM bus_units WHERE fleetNumber = :fleetNumber LIMIT 1")
    suspend fun getBusByFleetNumber(fleetNumber: String): BusUnit?

    @Query("SELECT * FROM bus_units WHERE fleetNumber LIKE '%' || :query || '%' OR plateNumber LIKE '%' || :query || '%' OR busName LIKE '%' || :query || '%' OR chassisModel LIKE '%' || :query || '%'")
    fun searchBuses(query: String): Flow<List<BusUnit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBus(bus: BusUnit): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuses(buses: List<BusUnit>)

    @Update
    suspend fun updateBus(bus: BusUnit)

    @Query("UPDATE bus_units SET currentOdometer = :newOdo, lastServiceDate = :serviceDate WHERE id = :busId")
    suspend fun updateOdometer(busId: Long, newOdo: Int, serviceDate: Long = System.currentTimeMillis())

    @Query("UPDATE bus_units SET operationalStatus = :status WHERE id = :busId")
    suspend fun updateStatus(busId: Long, status: String)

    @Delete
    suspend fun deleteBus(bus: BusUnit)

    @Query("SELECT COUNT(*) FROM bus_units")
    fun getTotalBusesCount(): Flow<Int>
}
