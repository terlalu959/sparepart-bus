package com.example.data.local

import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.MaintenanceLog
import com.example.data.model.SparePart

object DatabaseSeeder {

    suspend fun seedDatabase(db: AppDatabase) {
        val sparePartDao = db.sparePartDao()
        val busUnitDao = db.busUnitDao()
        val installedPartDao = db.installedPartDao()
        val maintenanceLogDao = db.maintenanceLogDao()

        // 1. Initial Spare Parts with realistic barcodes
        val initialParts = listOf(
            SparePart(
                id = 1,
                sku = "FLT-HNO-001",
                barcode = "899277501001",
                name = "Filter Oli Mesin J08E",
                category = "Filter",
                brand = "Hino Genuine Parts",
                stockQuantity = 18,
                minStockThreshold = 5,
                unit = "Pcs",
                rackLocation = "Rak A-01",
                price = 185000.0,
                specifications = "Filtrasi 10 Micron, Drat M26 x 1.5. Khusus mesin diesel common rail / konvensional.",
                compatibleBusModels = "Hino RK8 R260, Hino RN285, Hino AK8"
            ),
            SparePart(
                id = 2,
                sku = "BRK-BDX-002",
                barcode = "899277501002",
                name = "Kampas Rem Depan Heavy Duty",
                category = "Pengereman",
                brand = "Bendix Commercial",
                stockQuantity = 8,
                minStockThreshold = 4,
                unit = "Set",
                rackLocation = "Rak B-03",
                price = 850000.0,
                specifications = "Asbestos-free ceramic composite. Tahan panas hingga 650°C, daya cengkeram stabil di turunan tol.",
                compatibleBusModels = "Mercedes-Benz OH 1626, Hino RK8, Scania K360IB"
            ),
            SparePart(
                id = 3,
                sku = "SUS-FST-003",
                barcode = "899277501003",
                name = "Air Suspension Balon Belakang",
                category = "Suspensi",
                brand = "Firestone Airide",
                stockQuantity = 4,
                minStockThreshold = 2,
                unit = "Pcs",
                rackLocation = "Gudang Area C-1",
                price = 2450000.0,
                specifications = "Tipe 1T15M-6, Max Pressure 120 PSI. Bantalan karet 4 ply reinforced.",
                compatibleBusModels = "Mercedes-Benz OH 1626 L, Scania K360IB, Volvo B11R"
            ),
            SparePart(
                id = 4,
                sku = "BEL-GAT-004",
                barcode = "899277501004",
                name = "Fan Belt Alternator & AC 8PK1520",
                category = "Mesin",
                brand = "Gates EPDM Heavy",
                stockQuantity = 12,
                minStockThreshold = 4,
                unit = "Pcs",
                rackLocation = "Rak A-04",
                price = 295000.0,
                specifications = "8 Ribs panjang 1520mm, bahan EPDM anti slip suhu tinggi.",
                compatibleBusModels = "Mercedes-Benz OH 1526 / 1626, Hino RK8"
            ),
            SparePart(
                id = 5,
                sku = "OIL-SHL-005",
                barcode = "899277501005",
                name = "Oli Mesin Diesel Rimula R4X 15W-40 (Pail 20L)",
                category = "Pelumas",
                brand = "Shell Rimula",
                stockQuantity = 6,
                minStockThreshold = 3,
                unit = "Pail (20L)",
                rackLocation = "Gudang Pelumas D-01",
                price = 1150000.0,
                specifications = "API CI-4 / SL, ACEA E7, perlindungan keausan & deposit piston bus jarak jauh.",
                compatibleBusModels = "Semua Bus Mesin Diesel (Hino, Mercy, Scania)"
            ),
            SparePart(
                id = 6,
                sku = "INJ-DNS-006",
                barcode = "899277501006",
                name = "Nozzle Injector Common Rail G3S",
                category = "Mesin",
                brand = "Denso Japan",
                stockQuantity = 3, // Low stock!
                minStockThreshold = 4,
                unit = "Set",
                rackLocation = "Brankas Part Khusus B-1",
                price = 3750000.0,
                specifications = "Spray pattern 8 lubang mikro, presisi kalibrasi Euro 4/5.",
                compatibleBusModels = "Hino RN285, Mercedes OH 1626 Euro 4"
            ),
            SparePart(
                id = 7,
                sku = "FLT-DON-007",
                barcode = "899277501007",
                name = "Filter Udara Utama Primary Air Cleaner",
                category = "Filter",
                brand = "Donaldson RadialSeal",
                stockQuantity = 9,
                minStockThreshold = 3,
                unit = "Pcs",
                rackLocation = "Rak A-02",
                price = 420000.0,
                specifications = "Efisiensi filtrasi 99.9% debu jalanan jalur pantura & tol.",
                compatibleBusModels = "Scania K360IB, Mercedes OH 1626"
            ),
            SparePart(
                id = 8,
                sku = "ELC-BSC-008",
                barcode = "899277501008",
                name = "Alternator 28V 140A Heavy Bus",
                category = "Kelistrikan",
                brand = "Bosch Heavy Vehicle",
                stockQuantity = 2,
                minStockThreshold = 2,
                unit = "Unit",
                rackLocation = "Rak C-05",
                price = 4900000.0,
                specifications = "Output 28 Volt 140 Ampere, pengisian ganda baterai & AC audio kabin.",
                compatibleBusModels = "Mercedes-Benz OH 1626, Scania K360IB, Hino RK8"
            ),
            SparePart(
                id = 9,
                sku = "CLT-EXD-009",
                barcode = "899277501009",
                name = "Kampas Kopling / Clutch Disc 430mm",
                category = "Transmisi",
                brand = "Exedy Heavy Duty",
                stockQuantity = 2, // Low stock
                minStockThreshold = 3,
                unit = "Pcs",
                rackLocation = "Rak B-01",
                price = 3200000.0,
                specifications = "Diameter 430mm, 10 spline, damper spring ganda anti getaran transmisi.",
                compatibleBusModels = "Hino RK8, Mercedes OH 1526"
            ),
            SparePart(
                id = 10,
                sku = "WPR-VAL-010",
                barcode = "899277501010",
                name = "Wiper Blade Bus Kaca Depan 1000mm",
                category = "Body",
                brand = "Valeo Bus Vision",
                stockQuantity = 14,
                minStockThreshold = 6,
                unit = "Set",
                rackLocation = "Rak D-03",
                price = 280000.0,
                specifications = "Panjang 1000mm dengan nozzle washer terintegrasi untuk bus Double Glass / Single Glass.",
                compatibleBusModels = "Jetbus 3+, Avante H8, Legacy SR2"
            )
        )
        sparePartDao.insertParts(initialParts)

        // 2. Initial Bus Units
        val initialBuses = listOf(
            BusUnit(
                id = 1,
                fleetNumber = "BUS-01",
                plateNumber = "B 7890 TGA",
                busName = "Executive Jetbus 3+ Voyager",
                chassisModel = "Hino RK8JSKA-NHJ R260",
                year = 2021,
                route = "Jakarta - Surabaya (Via Tol Trans-Jawa)",
                currentOdometer = 184500,
                operationalStatus = "Beroperasi",
                driverName = "Pak Bambang S. & Mas Joko",
                lastServiceDate = System.currentTimeMillis() - (15L * 24 * 3600 * 1000),
                notes = "Unit prima, langganan trayek malam express Jakarta-Surabaya."
            ),
            BusUnit(
                id = 2,
                fleetNumber = "BUS-02",
                plateNumber = "AA 1688 ED",
                busName = "Super Executive Avante H8",
                chassisModel = "Mercedes-Benz OH 1626 L Air Suspension",
                year = 2022,
                route = "Jakarta - Solo - Wonogiri",
                currentOdometer = 142200,
                operationalStatus = "Beroperasi",
                driverName = "Pak Sugeng & Pak Hendra",
                lastServiceDate = System.currentTimeMillis() - (8L * 24 * 3600 * 1000),
                notes = "Suspensi udara sangat lembut, perawatan rutin setiap 15.000 KM."
            ),
            BusUnit(
                id = 3,
                fleetNumber = "BUS-03",
                plateNumber = "AD 7012 QA",
                busName = "Suite Class Legacy SR2 Trans-Jawa",
                chassisModel = "Scania K360IB Opticruise",
                year = 2023,
                route = "Jakarta - Malang (Sleeper Class)",
                currentOdometer = 98400,
                operationalStatus = "Beroperasi",
                driverName = "Pak Yanto & Mas Rizal",
                lastServiceDate = System.currentTimeMillis() - (5L * 24 * 3600 * 1000),
                notes = "Unit Sleeper premium armada andalan."
            ),
            BusUnit(
                id = 4,
                fleetNumber = "BUS-04",
                plateNumber = "DK 7450 AX",
                busName = "Pariwisata Tourismo HDD",
                chassisModel = "Mercedes-Benz OH 1526",
                year = 2020,
                route = "Pariwisata Khusus Jawa - Bali - Lombok",
                currentOdometer = 225000,
                operationalStatus = "Dalam Perawatan",
                driverName = "Pak Ketut & Pak Agus",
                lastServiceDate = System.currentTimeMillis() - (2L * 24 * 3600 * 1000),
                notes = "Sedang peremajaan kampas rem dan servis berkala di bengkel pool."
            )
        )
        busUnitDao.insertBuses(initialBuses)

        // 3. Initial Installed Parts on Buses
        val initialInstalled = listOf(
            // On BUS-01 (Current ODO 184500)
            InstalledPart(
                id = 1,
                busId = 1,
                sparePartId = 1,
                partName = "Filter Oli Mesin J08E",
                partSku = "FLT-HNO-001",
                partBarcode = "899277501001",
                partCategory = "Filter",
                installedDate = System.currentTimeMillis() - (35L * 24 * 3600 * 1000),
                installedOdometer = 175000,
                targetOdometerInterval = 10000, // Now: 184500 - 175000 = 9500 KM (95% used, almost time to change!)
                quantityInstalled = 1,
                technicianName = "Mekanik Sigit",
                installationPosition = "Blok Mesin Sisi Kanan",
                conditionStatus = "Perlu Pengecekan",
                isActive = true,
                notes = "Sudah menempuh 9.500 KM dari batas 10.000 KM."
            ),
            InstalledPart(
                id = 2,
                busId = 1,
                sparePartId = 2,
                partName = "Kampas Rem Depan Heavy Duty",
                partSku = "BRK-BDX-002",
                partBarcode = "899277501002",
                partCategory = "Pengereman",
                installedDate = System.currentTimeMillis() - (60L * 24 * 3600 * 1000),
                installedOdometer = 168000,
                targetOdometerInterval = 30000, // 16500 km used of 30k
                quantityInstalled = 1,
                technicianName = "Mekanik Wahyu",
                installationPosition = "Tromol Rem Roda Depan Kiri & Kanan",
                conditionStatus = "Normal",
                isActive = true,
                notes = "Ketebalan kampas masih 65%."
            ),
            InstalledPart(
                id = 3,
                busId = 1,
                sparePartId = 4,
                partName = "Fan Belt Alternator & AC 8PK1520",
                partSku = "BEL-GAT-004",
                partBarcode = "899277501004",
                partCategory = "Mesin",
                installedDate = System.currentTimeMillis() - (15L * 24 * 3600 * 1000),
                installedOdometer = 180000,
                targetOdometerInterval = 25000,
                quantityInstalled = 1,
                technicianName = "Mekanik Sigit",
                installationPosition = "Pulley Kruk As & AC Compressor",
                conditionStatus = "Bagus / Prima",
                isActive = true,
                notes = "Tegangan belt ideal, tidak ada retakan."
            ),

            // On BUS-02 (Current ODO 142200)
            InstalledPart(
                id = 4,
                busId = 2,
                sparePartId = 3,
                partName = "Air Suspension Balon Belakang",
                partSku = "SUS-FST-003",
                partBarcode = "899277501003",
                partCategory = "Suspensi",
                installedDate = System.currentTimeMillis() - (120L * 24 * 3600 * 1000),
                installedOdometer = 110000,
                targetOdometerInterval = 50000,
                quantityInstalled = 2,
                technicianName = "Mekanik Anton",
                installationPosition = "Suspensi Udara Gandan Belakang Kiri & Kanan",
                conditionStatus = "Bagus / Prima",
                isActive = true,
                notes = "Leveling valve stabil, tekanan balon seimbang 8.5 bar."
            ),
            InstalledPart(
                id = 5,
                busId = 2,
                sparePartId = 7,
                partName = "Filter Udara Utama Primary Air Cleaner",
                partSku = "FLT-DON-007",
                partBarcode = "899277501007",
                partCategory = "Filter",
                installedDate = System.currentTimeMillis() - (20L * 24 * 3600 * 1000),
                installedOdometer = 135000,
                targetOdometerInterval = 20000,
                quantityInstalled = 1,
                technicianName = "Mekanik Wahyu",
                installationPosition = "Rumah Filter Udara Sisi Kiri",
                conditionStatus = "Bagus / Prima",
                isActive = true,
                notes = "Kondisi elemen bersih."
            ),

            // On BUS-03 (Current ODO 98400)
            InstalledPart(
                id = 6,
                busId = 3,
                sparePartId = 8,
                partName = "Alternator 28V 140A Heavy Bus",
                partSku = "ELC-BSC-008",
                partBarcode = "899277501008",
                partCategory = "Kelistrikan",
                installedDate = System.currentTimeMillis() - (45L * 24 * 3600 * 1000),
                installedOdometer = 85000,
                targetOdometerInterval = 80000,
                quantityInstalled = 1,
                technicianName = "Teknisi Listrik Dani",
                installationPosition = "Dudukan Alternator Engine Bay",
                conditionStatus = "Bagus / Prima",
                isActive = true,
                notes = "Voltase charging stabil 28.4V saat beban AC penuh."
            ),

            // On BUS-04 (Current ODO 225000)
            InstalledPart(
                id = 7,
                busId = 4,
                sparePartId = 2,
                partName = "Kampas Rem Depan Heavy Duty",
                partSku = "BRK-BDX-002",
                partBarcode = "899277501002",
                partCategory = "Pengereman",
                installedDate = System.currentTimeMillis() - (180L * 24 * 3600 * 1000),
                installedOdometer = 194000,
                targetOdometerInterval = 30000, // 31000 km used > 30000 km target!
                quantityInstalled = 1,
                technicianName = "Mekanik Sigit",
                installationPosition = "Tromol Roda Depan",
                conditionStatus = "Aus / Segera Ganti",
                isActive = true,
                notes = "Ketebalan kampas di bawah 3mm, sudah dijadwalkan ganti hari ini."
            )
        )
        installedPartDao.insertInstalledParts(initialInstalled)

        // 4. Initial Maintenance Logs
        val initialLogs = listOf(
            MaintenanceLog(
                id = 1,
                busId = 1,
                sparePartId = 1,
                actionType = "PEMASANGAN",
                busFleetNumber = "BUS-01",
                busPlateNumber = "B 7890 TGA",
                partName = "Filter Oli Mesin J08E",
                partBarcode = "899277501001",
                quantity = 1,
                odometer = 175000,
                technicianName = "Mekanik Sigit",
                date = System.currentTimeMillis() - (35L * 24 * 3600 * 1000),
                notes = "Pemasangan berkala saat servis oli 175.000 KM."
            ),
            MaintenanceLog(
                id = 2,
                busId = 2,
                sparePartId = 3,
                actionType = "PEMASANGAN",
                busFleetNumber = "BUS-02",
                busPlateNumber = "AA 1688 ED",
                partName = "Air Suspension Balon Belakang",
                partBarcode = "899277501003",
                quantity = 2,
                odometer = 110000,
                technicianName = "Mekanik Anton",
                date = System.currentTimeMillis() - (120L * 24 * 3600 * 1000),
                notes = "Upgrade balon suspensi belakang ganda Firestone."
            ),
            MaintenanceLog(
                id = 3,
                busId = 4,
                sparePartId = 2,
                actionType = "PENGECEKAN",
                busFleetNumber = "BUS-04",
                busPlateNumber = "DK 7450 AX",
                partName = "Kampas Rem Depan Heavy Duty",
                partBarcode = "899277501002",
                quantity = 1,
                odometer = 225000,
                technicianName = "Mekanik Sigit",
                date = System.currentTimeMillis() - (2L * 24 * 3600 * 1000),
                notes = "Inspeksi rem menemukan kampas sudah aus 31.000 KM pemakaian."
            )
        )
        maintenanceLogDao.insertLogs(initialLogs)
    }
}
