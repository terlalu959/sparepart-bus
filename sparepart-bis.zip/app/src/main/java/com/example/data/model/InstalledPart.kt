package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "installed_parts",
    foreignKeys = [
        ForeignKey(
            entity = BusUnit::class,
            parentColumns = ["id"],
            childColumns = ["busId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SparePart::class,
            parentColumns = ["id"],
            childColumns = ["sparePartId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [
        Index(value = ["busId"]),
        Index(value = ["sparePartId"])
    ]
)
data class InstalledPart(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val busId: Long,
    val sparePartId: Long,
    val partName: String,
    val partSku: String,
    val partBarcode: String,
    val partCategory: String,
    val installedDate: Long = System.currentTimeMillis(),
    val installedOdometer: Int = 0, // KM saat dipasang
    val targetOdometerInterval: Int = 15000, // KM rekomendasi ganti
    val quantityInstalled: Int = 1,
    val technicianName: String = "Mekanik Pool Utama",
    val installationPosition: String = "Mesin", // Roda Depan Kanan, Suspensi Kiri, Rem Depan, dll
    val conditionStatus: String = "Bagus / Prima", // Bagus / Prima, Normal, Perlu Pengecekan, Aus / Segera Ganti
    val isActive: Boolean = true,
    val notes: String = ""
)
