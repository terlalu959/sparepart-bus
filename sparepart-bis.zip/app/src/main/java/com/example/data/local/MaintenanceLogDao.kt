package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.MaintenanceLog
import kotlinx.coroutines.flow.Flow

@Dao
interface MaintenanceLogDao {
    @Query("SELECT * FROM maintenance_logs ORDER BY date DESC")
    fun getAllLogs(): Flow<List<MaintenanceLog>>

    @Query("SELECT * FROM maintenance_logs WHERE busId = :busId ORDER BY date DESC")
    fun getLogsForBus(busId: Long): Flow<List<MaintenanceLog>>

    @Query("SELECT * FROM maintenance_logs WHERE sparePartId = :sparePartId ORDER BY date DESC")
    fun getLogsForPart(sparePartId: Long): Flow<List<MaintenanceLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: MaintenanceLog): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(logs: List<MaintenanceLog>)
}
