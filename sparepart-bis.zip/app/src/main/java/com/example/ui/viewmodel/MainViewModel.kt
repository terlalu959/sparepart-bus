package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.MaintenanceLog
import com.example.data.model.SparePart
import com.example.data.repository.BusPartsRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = BusPartsRepository(database)

    // Initial check
    init {
        viewModelScope.launch {
            repository.checkAndSeedInitialDataIfNeeded()
        }
    }

    // Navigation Tab
    // 0 = Dashboard, 1 = Spareparts, 2 = Armada Bis, 3 = Scan Barcode, 4 = Riwayat
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    fun setTab(index: Int) {
        _selectedTab.value = index
    }

    // Active Screen within tabs (e.g. Bus Detail screen)
    private val _selectedBusId = MutableStateFlow<Long?>(null)
    val selectedBusId: StateFlow<Long?> = _selectedBusId.asStateFlow()

    fun openBusDetail(busId: Long) {
        _selectedBusId.value = busId
    }

    fun closeBusDetail() {
        _selectedBusId.value = null
    }

    // Selected SparePart for detailed modal / Barcode Tag
    private val _selectedSparePart = MutableStateFlow<SparePart?>(null)
    val selectedSparePart: StateFlow<SparePart?> = _selectedSparePart.asStateFlow()

    fun selectSparePart(part: SparePart?) {
        _selectedSparePart.value = part
    }

    // Notification / Toast Message Flow
    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    // --- Search & Filter States ---
    val sparePartSearchQuery = MutableStateFlow("")
    val selectedCategoryFilter = MutableStateFlow("Semua")
    val selectedStockFilter = MutableStateFlow("Semua") // Semua, Aman, Kritis, Habis

    val busSearchQuery = MutableStateFlow("")
    val selectedBusStatusFilter = MutableStateFlow("Semua") // Semua, Beroperasi, Dalam Perawatan, Perbaikan, Standby

    // --- Master Data Flows ---
    val allSpareParts: StateFlow<List<SparePart>> = repository.allSpareParts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBuses: StateFlow<List<BusUnit>> = repository.allBuses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLogs: StateFlow<List<MaintenanceLog>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allActiveInstalledParts: StateFlow<List<InstalledPart>> = repository.allActiveInstalledParts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockParts: StateFlow<List<SparePart>> = repository.lowStockParts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Spare Parts
    val filteredSpareParts: StateFlow<List<SparePart>> = combine(
        allSpareParts,
        sparePartSearchQuery,
        selectedCategoryFilter,
        selectedStockFilter
    ) { parts, query, category, stockStatus ->
        parts.filter { part ->
            val matchesQuery = query.isBlank() ||
                    part.name.contains(query, ignoreCase = true) ||
                    part.barcode.contains(query, ignoreCase = true) ||
                    part.sku.contains(query, ignoreCase = true) ||
                    part.brand.contains(query, ignoreCase = true) ||
                    part.rackLocation.contains(query, ignoreCase = true)

            val matchesCategory = category == "Semua" || part.category.equals(category, ignoreCase = true)

            val matchesStock = when (stockStatus) {
                "Aman" -> part.stockQuantity > part.minStockThreshold
                "Kritis" -> part.stockQuantity in 1..part.minStockThreshold
                "Habis" -> part.stockQuantity <= 0
                else -> true
            }

            matchesQuery && matchesCategory && matchesStock
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Buses
    val filteredBuses: StateFlow<List<BusUnit>> = combine(
        allBuses,
        busSearchQuery,
        selectedBusStatusFilter
    ) { buses, query, status ->
        buses.filter { bus ->
            val matchesQuery = query.isBlank() ||
                    bus.fleetNumber.contains(query, ignoreCase = true) ||
                    bus.plateNumber.contains(query, ignoreCase = true) ||
                    bus.busName.contains(query, ignoreCase = true) ||
                    bus.chassisModel.contains(query, ignoreCase = true) ||
                    bus.route.contains(query, ignoreCase = true)

            val matchesStatus = status == "Semua" || bus.operationalStatus.equals(status, ignoreCase = true)

            matchesQuery && matchesStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Bus details & installed parts
    val currentSelectedBus: StateFlow<BusUnit?> = _selectedBusId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getBusByIdFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentBusInstalledParts: StateFlow<List<InstalledPart>> = _selectedBusId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getInstalledPartsForBus(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentBusLogs: StateFlow<List<MaintenanceLog>> = _selectedBusId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getLogsForBus(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Scanned Barcode Result Modal
    private val _scannedBarcodePart = MutableStateFlow<SparePart?>(null)
    val scannedBarcodePart: StateFlow<SparePart?> = _scannedBarcodePart.asStateFlow()

    private val _scannedBarcodeUnknown = MutableStateFlow<String?>(null)
    val scannedBarcodeUnknown: StateFlow<String?> = _scannedBarcodeUnknown.asStateFlow()

    fun onBarcodeScanned(barcode: String) {
        viewModelScope.launch {
            val part = repository.getPartByBarcode(barcode.trim())
            if (part != null) {
                _scannedBarcodePart.value = part
                _scannedBarcodeUnknown.value = null
                _userMessage.emit("Barcode terdeteksi: ${part.name}")
            } else {
                _scannedBarcodePart.value = null
                _scannedBarcodeUnknown.value = barcode.trim()
                _userMessage.emit("Barcode '$barcode' belum terdaftar di katalog")
            }
        }
    }

    fun dismissScannedResult() {
        _scannedBarcodePart.value = null
        _scannedBarcodeUnknown.value = null
    }

    // --- Actions ---

    fun saveSparePart(part: SparePart) {
        viewModelScope.launch {
            val id = repository.insertOrUpdateSparePart(part)
            _userMessage.emit("Data sparepart '${part.name}' berhasil disimpan")
            if (_selectedSparePart.value?.id == part.id) {
                _selectedSparePart.value = part.copy(id = if (part.id == 0L) id else part.id)
            }
        }
    }

    fun deleteSparePart(part: SparePart) {
        viewModelScope.launch {
            repository.deleteSparePart(part)
            _selectedSparePart.value = null
            _userMessage.emit("Sparepart '${part.name}' telah dihapus")
        }
    }

    fun saveBus(bus: BusUnit) {
        viewModelScope.launch {
            repository.insertOrUpdateBus(bus)
            _userMessage.emit("Data armada bus '${bus.fleetNumber} - ${bus.busName}' berhasil disimpan")
        }
    }

    fun deleteBus(bus: BusUnit) {
        viewModelScope.launch {
            repository.deleteBus(bus)
            if (_selectedBusId.value == bus.id) {
                _selectedBusId.value = null
            }
            _userMessage.emit("Unit bus '${bus.fleetNumber}' telah dihapus")
        }
    }

    fun updateBusOdometer(busId: Long, newOdo: Int) {
        viewModelScope.launch {
            repository.updateBusOdometer(busId, newOdo)
            _userMessage.emit("Odometer bus berhasil diupdate ke $newOdo KM")
        }
    }

    fun updateBusStatus(busId: Long, status: String) {
        viewModelScope.launch {
            repository.updateBusStatus(busId, status)
            _userMessage.emit("Status armada diubah menjadi: $status")
        }
    }

    fun installPartToBus(
        bus: BusUnit,
        part: SparePart,
        quantity: Int,
        position: String,
        technician: String,
        targetIntervalKm: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.installPartToBus(
                bus = bus,
                part = part,
                quantity = quantity,
                position = position,
                technician = technician,
                targetIntervalKm = targetIntervalKm,
                notes = notes
            )
            result.onSuccess {
                _userMessage.emit("Berhasil memasang ${part.name} ke ${bus.fleetNumber} (${bus.plateNumber})")
            }.onFailure { err ->
                _userMessage.emit("Gagal: ${err.message}")
            }
        }
    }

    fun replaceInstalledPart(
        oldInstalledPart: InstalledPart,
        bus: BusUnit,
        newPart: SparePart,
        quantity: Int,
        position: String,
        technician: String,
        targetIntervalKm: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val result = repository.replaceInstalledPart(
                oldInstalledPart = oldInstalledPart,
                bus = bus,
                newPart = newPart,
                quantity = quantity,
                position = position,
                technician = technician,
                targetIntervalKm = targetIntervalKm,
                notes = notes
            )
            result.onSuccess {
                _userMessage.emit("Komponen ${oldInstalledPart.partName} berhasil diganti dengan ${newPart.name}")
            }.onFailure { err ->
                _userMessage.emit("Gagal: ${err.message}")
            }
        }
    }

    fun uninstallPart(
        installedPart: InstalledPart,
        bus: BusUnit,
        returnStock: Boolean,
        technician: String,
        notes: String
    ) {
        viewModelScope.launch {
            repository.uninstallPart(
                installedPart = installedPart,
                bus = bus,
                returnStock = returnStock,
                technician = technician,
                notes = notes
            )
            _userMessage.emit("Komponen ${installedPart.partName} dilepas dari ${bus.fleetNumber}")
        }
    }

    fun updatePartCondition(installedPartId: Long, condition: String) {
        viewModelScope.launch {
            repository.updateInstalledPartCondition(installedPartId, condition)
            _userMessage.emit("Kondisi komponen diupdate: $condition")
        }
    }

    fun quickAdjustStock(part: SparePart, delta: Int, reason: String) {
        viewModelScope.launch {
            repository.quickAdjustStock(part, delta, reason)
            _userMessage.emit("Stok ${part.name} disesuaikan (${if (delta > 0) "+$delta" else "$delta"})")
        }
    }
}
