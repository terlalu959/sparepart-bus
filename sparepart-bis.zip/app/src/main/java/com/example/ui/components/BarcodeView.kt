package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SophisticatedDarkBorder
import com.example.ui.theme.SophisticatedDarkSurface
import com.example.ui.theme.SophisticatedOnPrimary
import com.example.ui.theme.SophisticatedPrimary
import com.example.ui.theme.SophisticatedTextMuted
import com.example.ui.theme.SophisticatedTextPrimary
import com.example.ui.theme.SophisticatedTextSecondary
import kotlin.math.abs

@Composable
fun BarcodeCard(
    barcode: String,
    sku: String,
    title: String,
    modifier: Modifier = Modifier,
    onTestScan: ((String) -> Unit)? = null
) {
    val context = LocalContext.current

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("barcode_card_$barcode"),
        shape = RoundedCornerShape(20.dp),
        color = SophisticatedDarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, SophisticatedDarkBorder)
    ) {
        Column(
            modifier = Modifier
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BARCODE TAG",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = SophisticatedTextMuted,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "SKU: $sku",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = SophisticatedPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Barcode Canvas container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(76.dp)
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                BarcodeCanvas(code = barcode)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Human Readable Text
            Text(
                text = barcode,
                style = MaterialTheme.typography.titleMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                color = SophisticatedTextPrimary
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = SophisticatedTextSecondary,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Barcode", barcode)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Barcode disalin: $barcode", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("copy_barcode_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SophisticatedDarkBorder)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Salin Kode",
                        tint = SophisticatedTextSecondary,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text("Salin Kode", color = SophisticatedTextSecondary)
                }

                if (onTestScan != null) {
                    Button(
                        onClick = { onTestScan(barcode) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_scan_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SophisticatedPrimary,
                            contentColor = SophisticatedOnPrimary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Tes Scan",
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text("Tes Scan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeCanvas(
    code: String,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
    ) {
        val cleanCode = code.ifBlank { "0000000000" }
        val barCount = 48
        val totalWidth = size.width
        val barWidth = totalWidth / (barCount * 1.5f)
        val height = size.height

        // Deterministic pattern generator based on hash/characters
        var xOffset = (totalWidth - (barCount * 1.5f * barWidth)) / 2f

        // Guard bars (start)
        drawRect(Color.Black, Offset(xOffset, 0f), Size(barWidth * 1.2f, height))
        xOffset += barWidth * 2f
        drawRect(Color.Black, Offset(xOffset, 0f), Size(barWidth * 1.2f, height))
        xOffset += barWidth * 2.5f

        // Variable data bars
        val charBytes = cleanCode.toByteArray()
        for (i in 0 until (barCount - 8)) {
            val charIndex = i % charBytes.size
            val charVal = abs(charBytes[charIndex].toInt() + i * 7)
            val isThick = (charVal % 3) == 0
            val isSkip = (charVal % 5) == 0

            val currentBarW = if (isThick) barWidth * 2.2f else barWidth * 1.1f

            if (!isSkip) {
                val barHeight = if (i == 18 || i == 19) height else height * 0.9f
                drawRect(
                    color = Color.Black,
                    topLeft = Offset(xOffset, 0f),
                    size = Size(currentBarW, barHeight)
                )
            }
            xOffset += currentBarW + (barWidth * 0.9f)
        }

        // Guard bars (end)
        drawRect(Color.Black, Offset(xOffset, 0f), Size(barWidth * 1.2f, height))
        xOffset += barWidth * 2f
        drawRect(Color.Black, Offset(xOffset, 0f), Size(barWidth * 1.2f, height))
    }
}
