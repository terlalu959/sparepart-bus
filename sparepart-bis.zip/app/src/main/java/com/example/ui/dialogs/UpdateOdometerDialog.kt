package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusUnit
import java.text.NumberFormat
import java.util.Locale

@Composable
fun UpdateOdometerDialog(
    bus: BusUnit,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    var odoText by remember { mutableStateOf(bus.currentOdometer.toString()) }
    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = { Text("Update Odometer Armada", fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5)) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "${bus.fleetNumber} (${bus.plateNumber})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFFD0BCFF)
                )
                Text(
                    text = "Odometer Tercatat Saat Ini: ${numberFormat.format(bus.currentOdometer)} KM",
                    fontSize = 12.sp,
                    color = Color(0xFFCAC4D0)
                )

                OutlinedTextField(
                    value = odoText,
                    onValueChange = { odoText = it },
                    label = { Text("Odometer Baru (KM)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("update_odo_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newOdo = odoText.toIntOrNull()
                    if (newOdo != null && newOdo >= 0) {
                        onConfirm(newOdo)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("confirm_update_odo_button")
            ) {
                Text("Simpan KM", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
