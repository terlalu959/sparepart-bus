package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SophisticatedAlert
import com.example.ui.theme.SophisticatedPrimary
import com.example.ui.theme.SophisticatedSuccess
import com.example.ui.theme.SophisticatedTextMuted
import com.example.ui.theme.SophisticatedTextPrimary
import com.example.ui.theme.SophisticatedTextSecondary
import com.example.ui.theme.SophisticatedWarning
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HealthProgressBar(
    installedOdo: Int,
    currentOdo: Int,
    targetIntervalKm: Int,
    modifier: Modifier = Modifier
) {
    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))
    val kmTraveled = (currentOdo - installedOdo).coerceAtLeast(0)
    val percentageUsed = if (targetIntervalKm > 0) {
        (kmTraveled.toFloat() / targetIntervalKm.toFloat()).coerceIn(0f, 1.5f)
    } else 0f

    val healthPercentage = ((1f - percentageUsed.coerceAtMost(1f)) * 100).toInt()

    val (barColor, statusText, statusTextColor) = when {
        percentageUsed >= 1.0f -> Triple(SophisticatedAlert, "Melewati Batas (Wajib Ganti)", SophisticatedAlert)
        percentageUsed >= 0.8f -> Triple(SophisticatedWarning, "Mendekati Batas Rekomendasi", SophisticatedWarning)
        percentageUsed >= 0.5f -> Triple(SophisticatedPrimary, "Kondisi Baik", SophisticatedPrimary)
        else -> Triple(SophisticatedSuccess, "Kondisi Sangat Prima", SophisticatedSuccess)
    }

    val animatedProgress by animateFloatAsState(
        targetValue = percentageUsed.coerceAtMost(1f),
        label = "wear_progress"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Umur Pakai: ${numberFormat.format(kmTraveled)} / ${numberFormat.format(targetIntervalKm)} KM",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = SophisticatedTextSecondary
            )
            Text(
                text = "$healthPercentage% Sehat",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = barColor
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Progress Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF49454F))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedProgress)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(4.dp))
                    .background(barColor)
            )
        }

        Spacer(modifier = Modifier.height(3.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = statusText,
                fontSize = 11.sp,
                color = statusTextColor,
                fontWeight = FontWeight.SemiBold
            )
            val kmRemaining = targetIntervalKm - kmTraveled
            if (kmRemaining > 0) {
                Text(
                    text = "Sisa ~${numberFormat.format(kmRemaining)} KM",
                    fontSize = 11.sp,
                    color = SophisticatedTextMuted
                )
            } else {
                Text(
                    text = "Lebih +${numberFormat.format(-kmRemaining)} KM",
                    fontSize = 11.sp,
                    color = SophisticatedAlert,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

