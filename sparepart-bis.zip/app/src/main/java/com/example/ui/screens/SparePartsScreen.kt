package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SparePart
import com.example.ui.components.CategoryBadge
import com.example.ui.components.StockBadge
import com.example.ui.theme.BusBlueLight
import com.example.ui.theme.BusBluePrimary
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SparePartsScreen(
    viewModel: MainViewModel,
    onAddPartClick: () -> Unit,
    onEditPartClick: (SparePart) -> Unit,
    onAdjustStockClick: (SparePart) -> Unit,
    onSelectPart: (SparePart) -> Unit,
    onTestScan: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val parts by viewModel.filteredSpareParts.collectAsStateWithLifecycle()
    val searchQuery by viewModel.sparePartSearchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val selectedStockFilter by viewModel.selectedStockFilter.collectAsStateWithLifecycle()

    val categories = listOf("Semua", "Mesin", "Pengereman", "Suspensi", "Filter", "Pelumas", "Kelistrikan", "Transmisi", "Body")
    val stockFilters = listOf("Semua", "Aman", "Kritis", "Habis")

    val currencyFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.sparePartSearchQuery.value = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("spare_part_search_input"),
                placeholder = { Text("Cari nama part, barcode, SKU, merk...", color = Color(0xFF938F99)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color(0xFFD0BCFF)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.sparePartSearchQuery.value = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFCAC4D0))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color(0xFFE6E1E5),
                    unfocusedTextColor = Color(0xFFE6E1E5),
                    focusedBorderColor = Color(0xFFD0BCFF),
                    unfocusedBorderColor = Color(0xFF49454F),
                    focusedContainerColor = Color(0xFF2B2930),
                    unfocusedContainerColor = Color(0xFF2B2930)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Category Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { viewModel.selectedCategoryFilter.value = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF4A4458),
                            selectedLabelColor = Color(0xFFD0BCFF),
                            containerColor = Color(0xFF2B2930),
                            labelColor = Color(0xFFCAC4D0)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategory == cat,
                            borderColor = if (selectedCategory == cat) Color(0xFFD0BCFF) else Color(0xFF49454F)
                        )
                    )
                }
            }

            // Stock Status Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                stockFilters.forEach { filter ->
                    FilterChip(
                        selected = selectedStockFilter == filter,
                        onClick = { viewModel.selectedStockFilter.value = filter },
                        label = { Text("Stok: $filter", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF4A4458),
                            selectedLabelColor = Color(0xFFD0BCFF),
                            containerColor = Color(0xFF2B2930),
                            labelColor = Color(0xFFCAC4D0)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedStockFilter == filter,
                            borderColor = if (selectedStockFilter == filter) Color(0xFFD0BCFF) else Color(0xFF49454F)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Parts List
            if (parts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = Color(0xFF938F99),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Tidak ada sparepart ditemukan",
                            color = Color(0xFFCAC4D0),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Coba ubah kata kunci pencarian atau filter kategori",
                            color = Color(0xFF938F99),
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                Text(
                    text = "Menampilkan ${parts.size} Sparepart",
                    fontSize = 12.sp,
                    color = Color(0xFFCAC4D0),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(parts, key = { it.id }) { part ->
                        SparePartCard(
                            part = part,
                            formattedPrice = currencyFormat.format(part.price),
                            onClick = { onSelectPart(part) },
                            onEdit = { onEditPartClick(part) },
                            onAdjustStock = { onAdjustStockClick(part) },
                            onTestScan = { onTestScan(part.barcode) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }

        // Floating Action Button to Add Part
        FloatingActionButton(
            onClick = onAddPartClick,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_spare_part_fab"),
            containerColor = Color(0xFFD0BCFF),
            contentColor = Color(0xFF381E72)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah Sparepart")
        }
    }
}

@Composable
fun SparePartCard(
    part: SparePart,
    formattedPrice: String,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onAdjustStock: () -> Unit,
    onTestScan: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("spare_part_card_${part.barcode}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: Category + Stock Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CategoryBadge(category = part.category)
                StockBadge(
                    quantity = part.stockQuantity,
                    minThreshold = part.minStockThreshold,
                    unit = part.unit
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Part Name
            Text(
                text = part.name,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )

            Spacer(modifier = Modifier.height(2.dp))

            // Brand & Price
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${part.brand} • SKU: ${part.sku}",
                    fontSize = 12.sp,
                    color = Color(0xFFCAC4D0)
                )
                if (part.price > 0) {
                    Text(
                        text = formattedPrice,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD0BCFF)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Barcode preview snippet
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF211F26),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = null,
                            tint = Color(0xFFCAC4D0),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = part.barcode,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFFE6E1E5)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Place,
                            contentDescription = null,
                            tint = Color(0xFF938F99),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = part.rackLocation,
                            fontSize = 11.sp,
                            color = Color(0xFFCAC4D0)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Card Bottom Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF352E46),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD0BCFF).copy(alpha = 0.3f)),
                    modifier = Modifier
                        .clickable { onTestScan() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = Color(0xFFD0BCFF),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Tes Scan", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD0BCFF))
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF3B2E1E),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD59E).copy(alpha = 0.3f)),
                    modifier = Modifier
                        .clickable { onAdjustStock() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("+/- Stok", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD59E))
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF36343B),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    modifier = Modifier
                        .clickable { onEdit() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Edit", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFCAC4D0))
                }
            }
        }
    }
}
