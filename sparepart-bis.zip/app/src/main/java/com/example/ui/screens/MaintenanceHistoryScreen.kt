package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MaintenanceLog
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceHistoryScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val logs by viewModel.allLogs.collectAsStateWithLifecycle()
    var selectedActionFilter by remember { mutableStateOf("Semua") }
    var searchQuery by remember { mutableStateOf("") }

    val actionTypes = listOf("Semua", "PEMASANGAN", "PENGGANTIAN", "PELEPASAN", "RESTOCK", "PENYESUAIAN")
    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))
    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))

    val filteredLogs = logs.filter { log ->
        val matchesAction = selectedActionFilter == "Semua" || log.actionType == selectedActionFilter
        val matchesQuery = searchQuery.isBlank() ||
                log.partName.contains(searchQuery, ignoreCase = true) ||
                log.busFleetNumber.contains(searchQuery, ignoreCase = true) ||
                log.busPlateNumber.contains(searchQuery, ignoreCase = true) ||
                log.partBarcode.contains(searchQuery, ignoreCase = true) ||
                log.technicianName.contains(searchQuery, ignoreCase = true)
        matchesAction && matchesQuery
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Search
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Cari log part, armada bus, barcode...", color = Color(0xFF938F99)) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color(0xFFD0BCFF))
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFFE6E1E5),
                unfocusedTextColor = Color(0xFFE6E1E5),
                focusedBorderColor = Color(0xFFD0BCFF),
                unfocusedBorderColor = Color(0xFF49454F),
                focusedContainerColor = Color(0xFF2B2930),
                unfocusedContainerColor = Color(0xFF2B2930)
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Action Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            actionTypes.forEach { action ->
                FilterChip(
                    selected = selectedActionFilter == action,
                    onClick = { selectedActionFilter = action },
                    label = { Text(action, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF4A4458),
                        selectedLabelColor = Color(0xFFD0BCFF),
                        containerColor = Color(0xFF2B2930),
                        labelColor = Color(0xFFCAC4D0)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selectedActionFilter == action,
                        borderColor = if (selectedActionFilter == action) Color(0xFFD0BCFF) else Color(0xFF49454F)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Total ${filteredLogs.size} Riwayat Transaksi",
            fontSize = 12.sp,
            color = Color(0xFFCAC4D0),
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        if (filteredLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = Color(0xFF938F99),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tidak ada riwayat mutasi / servis",
                        color = Color(0xFFCAC4D0),
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredLogs, key = { it.id }) { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val (badgeBg, badgeText, badgeColor) = when (log.actionType) {
                                    "PEMASANGAN" -> Triple(Color(0xFF1E3A20), "Pemasangan", Color(0xFFA6D3A0))
                                    "PENGGANTIAN" -> Triple(Color(0xFF352E46), "Penggantian", Color(0xFFD0BCFF))
                                    "PELEPASAN" -> Triple(Color(0xFF3B2222), "Pelepasan", Color(0xFFFFB4AB))
                                    "RESTOCK" -> Triple(Color(0xFF3B2E1E), "Restock Gudang", Color(0xFFFFD59E))
                                    "PENYESUAIAN" -> Triple(Color(0xFF322B38), "Penyesuaian", Color(0xFFE8DEF8))
                                    else -> Triple(Color(0xFF211F26), log.actionType, Color(0xFFCAC4D0))
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(badgeBg)
                                        .border(1.dp, badgeColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeColor
                                    )
                                }

                                Text(
                                    text = dateFormat.format(Date(log.date)),
                                    fontSize = 11.sp,
                                    color = Color(0xFF938F99)
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = log.partName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE6E1E5)
                            )

                            if (log.partBarcode != "-") {
                                Text(
                                    text = "Barcode: ${log.partBarcode}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFFCAC4D0)
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            if (log.busFleetNumber != "-") {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF211F26),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Unit: ${log.busFleetNumber} (${log.busPlateNumber})",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp,
                                            color = Color(0xFFD0BCFF)
                                        )
                                        if (log.odometer > 0) {
                                            Text(
                                                text = "ODO: ${numberFormat.format(log.odometer)} KM",
                                                fontSize = 11.sp,
                                                color = Color(0xFFCAC4D0)
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Petugas/Teknisi: ${log.technicianName} • Jml: ${log.quantity}",
                                fontSize = 11.sp,
                                color = Color(0xFFCAC4D0)
                            )

                            if (log.notes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = log.notes,
                                    fontSize = 11.sp,
                                    color = Color(0xFF938F99),
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }
    }
}
