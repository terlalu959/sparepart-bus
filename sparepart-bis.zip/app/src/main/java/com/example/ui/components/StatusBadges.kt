package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.SophisticatedAlert
import com.example.ui.theme.SophisticatedAlertBg
import com.example.ui.theme.SophisticatedPrimary
import com.example.ui.theme.SophisticatedSecondary
import com.example.ui.theme.SophisticatedSuccess
import com.example.ui.theme.SophisticatedSuccessBg
import com.example.ui.theme.SophisticatedWarning
import com.example.ui.theme.SophisticatedWarningBg

@Composable
fun BusStatusBadge(status: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, dotColor) = when (status) {
        "Beroperasi" -> Triple(SophisticatedSuccessBg, SophisticatedSuccess, SophisticatedSuccess)
        "Dalam Perawatan" -> Triple(SophisticatedWarningBg, SophisticatedWarning, SophisticatedWarning)
        "Perbaikan", "Perbaikan (Breakdown)" -> Triple(SophisticatedAlertBg, SophisticatedAlert, SophisticatedAlert)
        else -> Triple(Color(0xFF36343B), Color(0xFFCAC4D0), Color(0xFF938F99))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(1.dp, dotColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = status,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun StockBadge(quantity: Int, minThreshold: Int, unit: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor, label) = when {
        quantity <= 0 -> Triple(SophisticatedAlertBg, SophisticatedAlert, "Habis")
        quantity <= minThreshold -> Triple(SophisticatedWarningBg, SophisticatedWarning, "Kritis ($quantity $unit)")
        else -> Triple(SophisticatedSuccessBg, SophisticatedSuccess, "$quantity $unit")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ConditionBadge(condition: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when {
        condition.contains("Bagus") || condition.contains("Prima") -> Pair(SophisticatedSuccessBg, SophisticatedSuccess)
        condition.contains("Normal") -> Pair(Color(0xFF233648), Color(0xFF7DD3FC))
        condition.contains("Pengecekan") -> Pair(SophisticatedWarningBg, SophisticatedWarning)
        condition.contains("Aus") || condition.contains("Ganti") -> Pair(SophisticatedAlertBg, SophisticatedAlert)
        else -> Pair(Color(0xFF36343B), Color(0xFFCAC4D0))
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = condition,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun CategoryBadge(category: String, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (category) {
        "Mesin" -> Pair(Color(0xFF352E46), SophisticatedPrimary)
        "Pengereman" -> Pair(SophisticatedAlertBg, SophisticatedAlert)
        "Suspensi" -> Pair(SophisticatedWarningBg, SophisticatedWarning)
        "Filter" -> Pair(SophisticatedSuccessBg, SophisticatedSuccess)
        "Pelumas" -> Pair(Color(0xFF3A3022), Color(0xFFFFCC80))
        "Kelistrikan" -> Pair(Color(0xFF3E2D48), Color(0xFFE1BEE7))
        "Transmisi" -> Pair(Color(0xFF203842), Color(0xFF80DEEA))
        else -> Pair(Color(0xFF36343B), SophisticatedSecondary)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = category,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

