package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.BusUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditBusDialog(
    initialBus: BusUnit? = null,
    onDismiss: () -> Unit,
    onSave: (BusUnit) -> Unit
) {
    var fleetNumber by remember { mutableStateOf(initialBus?.fleetNumber ?: "BUS-05") }
    var plateNumber by remember { mutableStateOf(initialBus?.plateNumber ?: "B 7123 TGA") }
    var busName by remember { mutableStateOf(initialBus?.busName ?: "Jetbus 3+ HDD Voyager") }
    var chassisModel by remember { mutableStateOf(initialBus?.chassisModel ?: "Hino RK8JSKA-NHJ R260") }
    var year by remember { mutableStateOf(initialBus?.year?.toString() ?: "2023") }
    var route by remember { mutableStateOf(initialBus?.route ?: "Jakarta - Surabaya (Tol Trans-Jawa)") }
    var currentOdometer by remember { mutableStateOf(initialBus?.currentOdometer?.toString() ?: "50000") }
    var operationalStatus by remember { mutableStateOf(initialBus?.operationalStatus ?: "Beroperasi") }
    var statusExpanded by remember { mutableStateOf(false) }
    var driverName by remember { mutableStateOf(initialBus?.driverName ?: "Pak Driver & Tim") }
    var notes by remember { mutableStateOf(initialBus?.notes ?: "") }

    val statusList = listOf("Beroperasi", "Dalam Perawatan", "Perbaikan (Breakdown)", "Standby Pool")

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = {
            Text(
                if (initialBus == null) "Tambah Armada Bus Baru" else "Edit Data Armada Bus",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Fleet No & Plate No
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fleetNumber,
                        onValueChange = { fleetNumber = it },
                        label = { Text("No Lambung *") },
                        placeholder = { Text("BUS-05") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("bus_fleet_input")
                    )
                    OutlinedTextField(
                        value = plateNumber,
                        onValueChange = { plateNumber = it },
                        label = { Text("No Polisi *") },
                        placeholder = { Text("B 7890 TGA") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("bus_plate_input")
                    )
                }

                // Bus Name (Body/Karoseri)
                OutlinedTextField(
                    value = busName,
                    onValueChange = { busName = it },
                    label = { Text("Nama Bus / Karoseri") },
                    placeholder = { Text("Executive Jetbus 3+ Voyager") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Chassis Model & Year
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = chassisModel,
                        onValueChange = { chassisModel = it },
                        label = { Text("Tipe Chasis / Mesin") },
                        placeholder = { Text("Hino RK8 / Mercy 1626") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    )
                    OutlinedTextField(
                        value = year,
                        onValueChange = { year = it },
                        label = { Text("Tahun") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Route / Trayek
                OutlinedTextField(
                    value = route,
                    onValueChange = { route = it },
                    label = { Text("Rute / Trayek Operasional") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Odometer & Status
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = currentOdometer,
                        onValueChange = { currentOdometer = it },
                        label = { Text("Odometer (KM)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.2f)
                    )

                    ExposedDropdownMenuBox(
                        expanded = statusExpanded,
                        onExpandedChange = { statusExpanded = !statusExpanded },
                        modifier = Modifier.weight(1.5f)
                    ) {
                        OutlinedTextField(
                            value = operationalStatus,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Status") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                            colors = textFieldColors,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusExpanded,
                            onDismissRequest = { statusExpanded = false },
                            containerColor = Color(0xFF2B2930)
                        ) {
                            statusList.forEach { stat ->
                                DropdownMenuItem(
                                    text = { Text(stat, color = Color(0xFFE6E1E5)) },
                                    onClick = {
                                        operationalStatus = stat
                                        statusExpanded = false
                                    },
                                    colors = MenuDefaults.itemColors(
                                        textColor = Color(0xFFE6E1E5)
                                    )
                                )
                            }
                        }
                    }
                }

                // Driver
                OutlinedTextField(
                    value = driverName,
                    onValueChange = { driverName = it },
                    label = { Text("Nama Pengemudi / Kru") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Tambahan") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fleetNumber.isNotBlank() && plateNumber.isNotBlank()) {
                        val bus = BusUnit(
                            id = initialBus?.id ?: 0L,
                            fleetNumber = fleetNumber.trim(),
                            plateNumber = plateNumber.trim().uppercase(),
                            busName = busName.trim(),
                            chassisModel = chassisModel.trim(),
                            year = year.toIntOrNull() ?: 2022,
                            route = route.trim(),
                            currentOdometer = currentOdometer.toIntOrNull() ?: 0,
                            operationalStatus = operationalStatus,
                            driverName = driverName.trim(),
                            lastServiceDate = initialBus?.lastServiceDate ?: System.currentTimeMillis(),
                            notes = notes
                        )
                        onSave(bus)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("save_bus_button")
            ) {
                Text("Simpan", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
