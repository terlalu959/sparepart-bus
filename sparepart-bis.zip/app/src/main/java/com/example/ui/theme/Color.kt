package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Design Tokens
val SophisticatedDarkBg = Color(0xFF1C1B1F)
val SophisticatedDarkSurface = Color(0xFF2B2930)
val SophisticatedDarkSurfaceSubtle = Color(0xFF211F26)
val SophisticatedDarkBorder = Color(0xFF49454F)
val SophisticatedDarkBorderSubtle = Color(0xFF36343B)

val SophisticatedPrimary = Color(0xFFD0BCFF)
val SophisticatedOnPrimary = Color(0xFF381E72)
val SophisticatedPrimaryContainer = Color(0xFF4A4458)
val SophisticatedOnPrimaryContainer = Color(0xFFE8DEF8)

val SophisticatedSecondary = Color(0xFFCCC2DC)
val SophisticatedOnSecondary = Color(0xFF332D41)
val SophisticatedSecondaryContainer = Color(0xFF4A4458)
val SophisticatedOnSecondaryContainer = Color(0xFFE8DEF8)

val SophisticatedTertiary = Color(0xFFEFB8C8)
val SophisticatedOnTertiary = Color(0xFF492532)

val SophisticatedAlert = Color(0xFFFFB4AB)
val SophisticatedAlertBg = Color(0xFF3B2222)
val SophisticatedAlertText = Color(0xFFFFB4AB)

val SophisticatedWarning = Color(0xFFFFD59E)
val SophisticatedWarningBg = Color(0xFF3B2E1E)

val SophisticatedSuccess = Color(0xFFA6D3A0)
val SophisticatedSuccessBg = Color(0xFF1E3A20)

val SophisticatedTextPrimary = Color(0xFFE6E1E5)
val SophisticatedTextSecondary = Color(0xFFCAC4D0)
val SophisticatedTextMuted = Color(0xFF938F99)

// Backward compatibility & aliases
val BusBluePrimary = SophisticatedPrimary
val BusBlueDark = Color(0xFF4F378B)
val BusBlueLight = SophisticatedPrimary
val BusDark = SophisticatedDarkBg
val BusAmber = SophisticatedWarning
val BusAmberLight = Color(0xFFFFE082)
val BusEmerald = SophisticatedSuccess
val BusEmeraldLight = Color(0xFFC8E6C9)
val BusRose = SophisticatedAlert
val BusRoseLight = Color(0xFFFFCDD2)

// Dark Theme Colors
val DarkBackground = SophisticatedDarkBg
val DarkSurface = SophisticatedDarkSurface
val DarkSurfaceVariant = SophisticatedDarkSurfaceSubtle
val DarkOnSurface = SophisticatedTextPrimary
val DarkOnSurfaceVariant = SophisticatedTextSecondary
val DarkOutline = SophisticatedDarkBorder

// Light Theme Colors (Sophisticated Dark as standard aesthetic)
val LightBackground = SophisticatedDarkBg
val LightSurface = SophisticatedDarkSurface
val LightSurfaceVariant = SophisticatedDarkSurfaceSubtle
val LightOnSurface = SophisticatedTextPrimary
val LightOnSurfaceVariant = SophisticatedTextSecondary
val LightOutline = SophisticatedDarkBorder

