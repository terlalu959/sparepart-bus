package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusUnit
import com.example.data.model.SparePart

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstallPartDialog(
    preselectedBus: BusUnit? = null,
    preselectedPart: SparePart? = null,
    allBuses: List<BusUnit>,
    allParts: List<SparePart>,
    onDismiss: () -> Unit,
    onConfirm: (BusUnit, SparePart, Int, String, String, Int, String) -> Unit
) {
    var selectedBus by remember { mutableStateOf(preselectedBus ?: allBuses.firstOrNull()) }
    var busExpanded by remember { mutableStateOf(false) }

    var selectedPart by remember { mutableStateOf(preselectedPart ?: allParts.firstOrNull()) }
    var partExpanded by remember { mutableStateOf(false) }

    var quantity by remember { mutableStateOf("1") }
    var position by remember { mutableStateOf("Roda Depan Kanan") }
    var technician by remember { mutableStateOf("Bambang (Kepala Mekanik)") }
    var targetIntervalKm by remember {
        mutableStateOf(
            when (selectedPart?.category) {
                "Pelumas", "Filter" -> "10000"
                "Pengereman" -> "25000"
                "Suspensi" -> "40000"
                "Transmisi" -> "30000"
                else -> "20000"
            }
        )
    }
    var notes by remember { mutableStateOf("Pemasangan part baru berkala") }

    val presetPositions = listOf(
        "Roda Depan Kanan",
        "Roda Depan Kiri",
        "Roda Belakang Luar Kanan",
        "Roda Belakang Dalam Kanan",
        "Roda Belakang Luar Kiri",
        "Roda Belakang Dalam Kiri",
        "Blok Mesin Sisi Kanan",
        "Blok Mesin Sisi Kiri",
        "Engine Bay / Ruang Mesin",
        "Suspensi Gandar Depan",
        "Suspensi Balon Gandar Belakang",
        "Transmisi / Kopling",
        "Sistem Kelistrikan Dashboard",
        "Kabin & Body Luar"
    )
    var positionExpanded by remember { mutableStateOf(false) }

    val currentStock = selectedPart?.stockQuantity ?: 0

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = { Text("Pasang Sparepart ke Armada Bus", fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5)) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Bus Selector (if not preselected)
                if (preselectedBus == null) {
                    ExposedDropdownMenuBox(
                        expanded = busExpanded,
                        onExpandedChange = { busExpanded = !busExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedBus?.let { "${it.fleetNumber} - ${it.plateNumber} (${it.busName})" } ?: "Pilih Unit Bus",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target Unit Bus *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = busExpanded) },
                            colors = textFieldColors,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = busExpanded,
                            onDismissRequest = { busExpanded = false },
                            containerColor = Color(0xFF2B2930)
                        ) {
                            allBuses.forEach { bus ->
                                DropdownMenuItem(
                                    text = { Text("${bus.fleetNumber} - ${bus.plateNumber} (${bus.busName})", color = Color(0xFFE6E1E5)) },
                                    onClick = {
                                        selectedBus = bus
                                        busExpanded = false
                                    },
                                    colors = MenuDefaults.itemColors(textColor = Color(0xFFE6E1E5))
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Unit Bus: ${preselectedBus.fleetNumber} (${preselectedBus.plateNumber})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFFD0BCFF)
                    )
                }

                // Part Selector (if not preselected)
                if (preselectedPart == null) {
                    ExposedDropdownMenuBox(
                        expanded = partExpanded,
                        onExpandedChange = { partExpanded = !partExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedPart?.let { "${it.name} (Stok: ${it.stockQuantity})" } ?: "Pilih Sparepart",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Pilih Sparepart *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = partExpanded) },
                            colors = textFieldColors,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = partExpanded,
                            onDismissRequest = { partExpanded = false },
                            containerColor = Color(0xFF2B2930)
                        ) {
                            allParts.forEach { part ->
                                DropdownMenuItem(
                                    text = { Text("${part.name} - [Stok: ${part.stockQuantity} ${part.unit}]", color = Color(0xFFE6E1E5)) },
                                    onClick = {
                                        selectedPart = part
                                        targetIntervalKm = when (part.category) {
                                            "Pelumas", "Filter" -> "10000"
                                            "Pengereman" -> "25000"
                                            "Suspensi" -> "40000"
                                            else -> "20000"
                                        }
                                        partExpanded = false
                                    },
                                    colors = MenuDefaults.itemColors(textColor = Color(0xFFE6E1E5))
                                )
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Sparepart: ${preselectedPart.name} (${preselectedPart.barcode})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFFE6E1E5)
                    )
                }

                // Stock alert if 0
                if (currentStock <= 0) {
                    Text(
                        text = "⚠️ Stok sparepart ini di gudang kosong (0). Pemasangan akan mencatat stok minus!",
                        color = Color(0xFFFFB4AB),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Quantity & Target KM Interval
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Jumlah Terpasang") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = targetIntervalKm,
                        onValueChange = { targetIntervalKm = it },
                        label = { Text("Target Pakai (KM)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.3f)
                    )
                }

                // Position on Bus
                ExposedDropdownMenuBox(
                    expanded = positionExpanded,
                    onExpandedChange = { positionExpanded = !positionExpanded }
                ) {
                    OutlinedTextField(
                        value = position,
                        onValueChange = { position = it },
                        label = { Text("Posisi Pemasangan pada Unit *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = positionExpanded) },
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = positionExpanded,
                        onDismissRequest = { positionExpanded = false },
                        containerColor = Color(0xFF2B2930)
                    ) {
                        presetPositions.forEach { pos ->
                            DropdownMenuItem(
                                text = { Text(pos, color = Color(0xFFE6E1E5)) },
                                onClick = {
                                    position = pos
                                    positionExpanded = false
                                },
                                colors = MenuDefaults.itemColors(textColor = Color(0xFFE6E1E5))
                            )
                        }
                    }
                }

                // Technician
                OutlinedTextField(
                    value = technician,
                    onValueChange = { technician = it },
                    label = { Text("Nama Teknisi / Mekanik") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Pemasangan") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedBus != null && selectedPart != null) {
                        onConfirm(
                            selectedBus!!,
                            selectedPart!!,
                            quantity.toIntOrNull() ?: 1,
                            position.trim(),
                            technician.trim(),
                            targetIntervalKm.toIntOrNull() ?: 20000,
                            notes.trim()
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("confirm_install_button")
            ) {
                Text("Pasang Sekarang", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
