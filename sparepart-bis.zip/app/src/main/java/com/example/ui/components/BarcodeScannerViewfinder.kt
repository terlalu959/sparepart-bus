package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SparePart

@Composable
fun BarcodeScannerViewfinder(
    onBarcodeScanned: (String) -> Unit,
    availableParts: List<SparePart> = emptyList(),
    modifier: Modifier = Modifier
) {
    var manualInput by remember { mutableStateOf("") }
    var isFlashlightOn by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    val infiniteTransition = rememberInfiniteTransition(label = "laser_transition")
    val laserPosition by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_pos"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1C1B1F))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Pemindai Barcode / QR",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color(0xFFE6E1E5),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Arahkan kamera ke barcode part bus",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF938F99)
                )
            }

            IconButton(
                onClick = { isFlashlightOn = !isFlashlightOn },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isFlashlightOn) Color(0xFFFFD59E) else Color(0xFF2B2930))
                    .border(1.dp, Color(0xFF49454F), CircleShape)
                    .testTag("flashlight_toggle")
            ) {
                Icon(
                    imageVector = if (isFlashlightOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    contentDescription = "Flashlight Toggle",
                    tint = if (isFlashlightOn) Color(0xFF381E72) else Color(0xFFE6E1E5)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Viewfinder Frame
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .aspectRatio(1.1f)
                .clip(RoundedCornerShape(24.dp))
                .background(if (isFlashlightOn) Color(0xFF2B2930) else Color(0xFF141218))
                .border(2.dp, Color(0xFF49454F), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Live CameraX Scanner Preview with ML Kit
            CameraBarcodeScanner(
                onBarcodeDetected = onBarcodeScanned,
                isFlashlightOn = isFlashlightOn,
                modifier = Modifier.fillMaxSize()
            )

            // Corner Reticles & Laser Canvas Overlay
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val cornerLength = 40.dp.toPx()
                val cornerStroke = 4.dp.toPx()
                val cornerColor = Color(0xFFD0BCFF)

                // Top-Left corner
                drawLine(cornerColor, Offset(16.dp.toPx(), 16.dp.toPx()), Offset(16.dp.toPx() + cornerLength, 16.dp.toPx()), cornerStroke)
                drawLine(cornerColor, Offset(16.dp.toPx(), 16.dp.toPx()), Offset(16.dp.toPx(), 16.dp.toPx() + cornerLength), cornerStroke)

                // Top-Right corner
                drawLine(cornerColor, Offset(w - 16.dp.toPx(), 16.dp.toPx()), Offset(w - 16.dp.toPx() - cornerLength, 16.dp.toPx()), cornerStroke)
                drawLine(cornerColor, Offset(w - 16.dp.toPx(), 16.dp.toPx()), Offset(w - 16.dp.toPx(), 16.dp.toPx() + cornerLength), cornerStroke)

                // Bottom-Left corner
                drawLine(cornerColor, Offset(16.dp.toPx(), h - 16.dp.toPx()), Offset(16.dp.toPx() + cornerLength, h - 16.dp.toPx()), cornerStroke)
                drawLine(cornerColor, Offset(16.dp.toPx(), h - 16.dp.toPx()), Offset(16.dp.toPx(), h - 16.dp.toPx() - cornerLength), cornerStroke)

                // Bottom-Right corner
                drawLine(cornerColor, Offset(w - 16.dp.toPx(), h - 16.dp.toPx()), Offset(w - 16.dp.toPx() - cornerLength, h - 16.dp.toPx()), cornerStroke)
                drawLine(cornerColor, Offset(w - 16.dp.toPx(), h - 16.dp.toPx()), Offset(w - 16.dp.toPx(), h - 16.dp.toPx() - cornerLength), cornerStroke)

                // Animated Laser Line
                val currentY = h * laserPosition
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFFD0BCFF),
                            Color(0xFFEFB8C8),
                            Color(0xFFD0BCFF),
                            Color.Transparent
                        )
                    ),
                    start = Offset(24.dp.toPx(), currentY),
                    end = Offset(w - 24.dp.toPx(), currentY),
                    strokeWidth = 3.dp.toPx()
                )
            }

            // Central Guide
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = null,
                    tint = Color(0xFFD0BCFF).copy(alpha = 0.5f),
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Posisikan Barcode di Kotak Ini",
                    color = Color(0xFFCAC4D0),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Manual Barcode Input
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Input Barcode Manual",
                    color = Color(0xFFCAC4D0),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = manualInput,
                        onValueChange = { manualInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("manual_barcode_input"),
                        placeholder = { Text("Contoh: 899277501001", color = Color(0xFF938F99), fontSize = 13.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Search
                        ),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                if (manualInput.isNotBlank()) {
                                    focusManager.clearFocus()
                                    onBarcodeScanned(manualInput.trim())
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color(0xFFE6E1E5),
                            unfocusedTextColor = Color(0xFFE6E1E5),
                            focusedBorderColor = Color(0xFFD0BCFF),
                            unfocusedBorderColor = Color(0xFF49454F)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (manualInput.isNotBlank()) {
                                focusManager.clearFocus()
                                onBarcodeScanned(manualInput.trim())
                            }
                        },
                        modifier = Modifier.testTag("submit_manual_barcode"),
                        shape = RoundedCornerShape(10.dp),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFD0BCFF),
                            contentColor = Color(0xFF381E72)
                        )
                    ) {
                        Text("Cari", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Test Barcode Picker (Very helpful for testing instant scan!)
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tes Cepat Barcode Sparepart",
                    color = Color(0xFFE6E1E5),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Klik untuk tes scan",
                    color = Color(0xFFD0BCFF),
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(availableParts) { part ->
                    Surface(
                        modifier = Modifier
                            .clickable {
                                onBarcodeScanned(part.barcode)
                            }
                            .testTag("test_barcode_chip_${part.barcode}"),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF2B2930),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = Color(0xFFD0BCFF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = part.name,
                                    color = Color(0xFFE6E1E5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                                Text(
                                    text = part.barcode,
                                    color = Color(0xFF938F99),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
