package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusUnit
import com.example.data.model.SparePart
import com.example.ui.components.BarcodeCard
import com.example.ui.components.BarcodeScannerViewfinder
import com.example.ui.components.CategoryBadge
import com.example.ui.components.StockBadge
import com.example.ui.theme.BusBlueLight
import com.example.ui.theme.BusBluePrimary
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarcodeScanScreen(
    viewModel: MainViewModel,
    onInstallScannedPartToBus: (SparePart) -> Unit,
    onAdjustScannedStock: (SparePart) -> Unit,
    onViewScannedDetail: (SparePart) -> Unit,
    onAddNewPartWithBarcode: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val allParts by viewModel.allSpareParts.collectAsStateWithLifecycle()
    val scannedPart by viewModel.scannedBarcodePart.collectAsStateWithLifecycle()
    val unknownBarcode by viewModel.scannedBarcodeUnknown.collectAsStateWithLifecycle()
    val allInstalled by viewModel.allActiveInstalledParts.collectAsStateWithLifecycle()
    val allBuses by viewModel.allBuses.collectAsStateWithLifecycle()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Box(modifier = modifier.fillMaxSize()) {
        // Main Viewfinder
        BarcodeScannerViewfinder(
            onBarcodeScanned = { barcode ->
                viewModel.onBarcodeScanned(barcode)
            },
            availableParts = allParts
        )

        // Scanned Result Bottom Sheet (Found Part)
        if (scannedPart != null) {
            val part = scannedPart!!
            val busesUsingPart = allInstalled.filter { it.sparePartId == part.id }

            ModalBottomSheet(
                onDismissRequest = { viewModel.dismissScannedResult() },
                sheetState = sheetState,
                containerColor = Color(0xFF2B2930),
                contentColor = Color(0xFFE6E1E5)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .testTag("scanned_result_sheet")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color(0xFFA6D3A0),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Barcode Terverifikasi",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFA6D3A0)
                            )
                        }

                        IconButton(onClick = { viewModel.dismissScannedResult() }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = Color(0xFFCAC4D0))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Barcode Preview Card
                    BarcodeCard(
                        barcode = part.barcode,
                        sku = part.sku,
                        title = part.name,
                        onTestScan = null
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Stock & Location Info
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF1C1B1F),
                        modifier = Modifier.fillMaxWidth(),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CategoryBadge(category = part.category)
                                StockBadge(
                                    quantity = part.stockQuantity,
                                    minThreshold = part.minStockThreshold,
                                    unit = part.unit
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Lokasi: ${part.rackLocation} • Merk: ${part.brand}",
                                fontSize = 12.sp,
                                color = Color(0xFFCAC4D0)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Buses currently using this part
                    Text(
                        text = "Unit Bis Yang Menggunakan (${busesUsingPart.size} Unit):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E5)
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    if (busesUsingPart.isEmpty()) {
                        Text(
                            text = "Belum terpasang pada armada bus manapun",
                            fontSize = 12.sp,
                            color = Color(0xFF938F99)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            busesUsingPart.forEach { installed ->
                                val bus = allBuses.find { it.id == installed.busId }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF1C1B1F),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${bus?.fleetNumber ?: "-"} (${bus?.plateNumber ?: "-"})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Color(0xFFE6E1E5)
                                        )
                                        Text(
                                            text = installed.installationPosition,
                                            fontSize = 11.sp,
                                            color = Color(0xFFCAC4D0)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.dismissScannedResult()
                                onInstallScannedPartToBus(part)
                            },
                            modifier = Modifier
                                .weight(1.3f)
                                .height(44.dp)
                                .testTag("scan_install_to_bus_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.DirectionsBus, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pasang ke Bis", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.dismissScannedResult()
                                onAdjustScannedStock(part)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("scan_adjust_stock_button"),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+/- Stok", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.dismissScannedResult()
                                onViewScannedDetail(part)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("scan_view_detail_button"),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Detail", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        // Unknown Barcode Bottom Sheet
        if (unknownBarcode != null) {
            val code = unknownBarcode!!
            ModalBottomSheet(
                onDismissRequest = { viewModel.dismissScannedResult() },
                sheetState = sheetState,
                containerColor = Color(0xFF2B2930),
                contentColor = Color(0xFFE6E1E5)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .testTag("unknown_barcode_sheet"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color(0xFFFFD59E),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Barcode Belum Terdaftar",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE6E1E5)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Kode Barcode: $code",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD0BCFF),
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Barcode ini belum ada di data sparepart. Daftarkan sekarang sebagai sparepart baru?",
                        color = Color(0xFFCAC4D0),
                        fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.dismissScannedResult() },
                            modifier = Modifier.weight(1f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Batal")
                        }

                        Button(
                            onClick = {
                                viewModel.dismissScannedResult()
                                onAddNewPartWithBarcode(code)
                            },
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Daftarkan Part", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}
