package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.SparePart
import com.example.ui.components.BarcodeCard
import com.example.ui.components.CategoryBadge
import com.example.ui.components.StockBadge
import com.example.ui.theme.BusRose
import java.text.NumberFormat
import java.util.Locale

@Composable
fun PartDetailDialog(
    part: SparePart,
    allBuses: List<BusUnit>,
    installedParts: List<InstalledPart>,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAdjustStock: () -> Unit,
    onInstallToBus: () -> Unit,
    onTestScan: (String) -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val busesUsingThisPart = installedParts.filter { it.sparePartId == part.id }
    val currencyFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
        maximumFractionDigits = 0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Detail Sparepart",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE6E1E5)
                )
                Row {
                    IconButton(onClick = onEdit) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Part", tint = Color(0xFFD0BCFF))
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Hapus Part", tint = Color(0xFFFFB4AB))
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Barcode Card Display
                BarcodeCard(
                    barcode = part.barcode,
                    sku = part.sku,
                    title = part.name,
                    onTestScan = { onTestScan(part.barcode) }
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Info Rows
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF211F26),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CategoryBadge(category = part.category)
                            StockBadge(
                                quantity = part.stockQuantity,
                                minThreshold = part.minStockThreshold,
                                unit = part.unit
                            )
                        }

                        Text(
                            text = "Merk: ${part.brand}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE6E1E5)
                        )

                        if (part.price > 0) {
                            Text(
                                text = "Harga: ${currencyFormat.format(part.price)} / ${part.unit}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFD0BCFF)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = null,
                                tint = Color(0xFFCAC4D0),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Lokasi Rak: ${part.rackLocation}",
                                fontSize = 12.sp,
                                color = Color(0xFFCAC4D0)
                            )
                        }

                        if (part.specifications.isNotBlank()) {
                            Text(
                                text = "Spesifikasi: ${part.specifications}",
                                fontSize = 12.sp,
                                color = Color(0xFFCAC4D0)
                            )
                        }

                        if (part.compatibleBusModels.isNotBlank()) {
                            Text(
                                text = "Kompatibilitas: ${part.compatibleBusModels}",
                                fontSize = 12.sp,
                                color = Color(0xFFD0BCFF),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Active Buses Using this Part
                Text(
                    text = "Unit Bis Yang Menggunakan (${busesUsingThisPart.size} Unit):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE6E1E5)
                )

                if (busesUsingThisPart.isEmpty()) {
                    Text(
                        text = "Belum ada unit bus yang memasang part ini saat ini.",
                        fontSize = 12.sp,
                        color = Color(0xFF938F99)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        busesUsingThisPart.forEach { installed ->
                            val bus = allBuses.find { it.id == installed.busId }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF211F26),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${bus?.fleetNumber ?: "-"} (${bus?.plateNumber ?: "-"})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = Color(0xFFE6E1E5)
                                        )
                                        Text(
                                            text = "Posisi: ${installed.installationPosition}",
                                            fontSize = 11.sp,
                                            color = Color(0xFFCAC4D0)
                                        )
                                    }
                                    Text(
                                        text = installed.conditionStatus,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFA6D3A0)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onAdjustStock,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD0BCFF))
                ) {
                    Text("+/- Stok", fontSize = 12.sp)
                }
                Button(
                    onClick = onInstallToBus,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD0BCFF), contentColor = Color(0xFF381E72))
                ) {
                    Text("Pasang ke Bis", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Tutup")
            }
        }
    )

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = Color(0xFF2B2930),
            titleContentColor = Color(0xFFE6E1E5),
            textContentColor = Color(0xFFCAC4D0),
            title = { Text("Hapus Data Sparepart", color = Color(0xFFE6E1E5)) },
            text = {
                Text("Apakah Anda yakin ingin menghapus '${part.name}' dari database? Tindakan ini tidak dapat dibatalkan.", color = Color(0xFFCAC4D0))
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDismiss()
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF93000A), contentColor = Color(0xFFFFB4AB))
                ) {
                    Text("Ya, Hapus")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirm = false },
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
                ) {
                    Text("Batal")
                }
            }
        )
    }
}
