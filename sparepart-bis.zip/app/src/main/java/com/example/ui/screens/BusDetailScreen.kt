package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.MaintenanceLog
import com.example.ui.components.BusStatusBadge
import com.example.ui.components.CategoryBadge
import com.example.ui.components.ConditionBadge
import com.example.ui.components.HealthProgressBar
import com.example.ui.theme.BusAmber
import com.example.ui.theme.BusBluePrimary
import com.example.ui.theme.BusEmerald
import com.example.ui.theme.BusRose
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusDetailScreen(
    viewModel: MainViewModel,
    onBackClick: () -> Unit,
    onInstallPartClick: (BusUnit) -> Unit,
    onReplacePartClick: (InstalledPart, BusUnit) -> Unit,
    onEditBusClick: (BusUnit) -> Unit,
    onUpdateOdoClick: (BusUnit) -> Unit,
    onScanForThisBus: (BusUnit) -> Unit,
    modifier: Modifier = Modifier
) {
    val bus by viewModel.currentSelectedBus.collectAsStateWithLifecycle()
    val installedParts by viewModel.currentBusInstalledParts.collectAsStateWithLifecycle()
    val logs by viewModel.currentBusLogs.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))
    val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))

    if (bus == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Data unit bus tidak ditemukan")
        }
        return
    }

    val currentBus = bus!!

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1C1B1F))
    ) {
        // Top App Bar
        Surface(
            color = Color(0xFF2B2930),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("bus_detail_back_button")) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = Color(0xFFE6E1E5))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Detail Armada: ${currentBus.fleetNumber}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFFE6E1E5)
                    )
                    Text(
                        text = currentBus.plateNumber,
                        fontSize = 12.sp,
                        color = Color(0xFFD0BCFF),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(onClick = { onEditBusClick(currentBus) }) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Bus", tint = Color(0xFFCAC4D0))
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Bus Specification Header Card
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = currentBus.busName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE6E1E5)
                            )
                            BusStatusBadge(status = currentBus.operationalStatus)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Chasis: ${currentBus.chassisModel} (Tahun ${currentBus.year})",
                            fontSize = 13.sp,
                            color = Color(0xFFCAC4D0)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Info Items Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFF211F26),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B))
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Route,
                                        contentDescription = null,
                                        tint = Color(0xFFD0BCFF),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("Trayek / Rute", fontSize = 10.sp, color = Color(0xFF938F99))
                                        Text(currentBus.route, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5), maxLines = 1)
                                    }
                                }
                            }

                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFF211F26),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B))
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = Color(0xFFA6D3A0),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text("Kru / Driver", fontSize = 10.sp, color = Color(0xFF938F99))
                                        Text(currentBus.driverName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5), maxLines = 1)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Odometer Banner with Quick Update Button
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF211F26),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Odometer Saat Ini", fontSize = 11.sp, color = Color(0xFFCAC4D0))
                                    Text(
                                        text = "${numberFormat.format(currentBus.currentOdometer)} KM",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFE6E1E5),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Button(
                                    onClick = { onUpdateOdoClick(currentBus) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFD0BCFF),
                                        contentColor = Color(0xFF381E72)
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("update_odo_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Speed,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Update KM", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Tabs Selector
            item {
                PrimaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color(0xFF2B2930),
                    contentColor = Color(0xFFD0BCFF),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF49454F), RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "Komponen Terpasang (${installedParts.size})",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) Color(0xFFD0BCFF) else Color(0xFF938F99)
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                "Riwayat Servis (${logs.size})",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) Color(0xFFD0BCFF) else Color(0xFF938F99)
                            )
                        }
                    )
                }
            }

            // Tab 0: Komponen Terpasang (Installed Spareparts)
            if (selectedTab == 0) {
                item {
                    // Big Action Button: Pasang Sparepart Baru
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onInstallPartClick(currentBus) },
                            modifier = Modifier
                                .weight(1.3f)
                                .height(44.dp)
                                .testTag("install_new_part_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            )
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Pasang Sparepart", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onScanForThisBus(currentBus) },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("scan_part_for_bus_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                        ) {
                            Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = Color(0xFFD0BCFF), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Scan Part", fontSize = 12.sp, color = Color(0xFFE6E1E5))
                        }
                    }
                }

                if (installedParts.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Build,
                                    contentDescription = null,
                                    tint = Color(0xFF938F99),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Belum ada sparepart terpasang pada unit ini",
                                    color = Color(0xFFCAC4D0),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Klik '+ Pasang Sparepart' atau 'Scan Part' untuk mendaftarkan komponen bus ini.",
                                    color = Color(0xFF938F99),
                                    fontSize = 12.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    items(installedParts, key = { it.id }) { installed ->
                        InstalledPartDetailCard(
                            installedPart = installed,
                            currentOdo = currentBus.currentOdometer,
                            onReplace = { onReplacePartClick(installed, currentBus) },
                            onUpdateCondition = { newCond ->
                                viewModel.updatePartCondition(installed.id, newCond)
                            },
                            onUninstall = { returnStock ->
                                viewModel.uninstallPart(
                                    installedPart = installed,
                                    bus = currentBus,
                                    returnStock = returnStock,
                                    technician = "Mekanik Pool",
                                    notes = "Pelepasan rutin di bengkel"
                                )
                            }
                        )
                    }
                }
            }

            // Tab 1: Riwayat Servis & Log
            if (selectedTab == 1) {
                if (logs.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Belum ada riwayat servis untuk bus ini", color = Color(0xFF938F99))
                            }
                        }
                    }
                } else {
                    items(logs, key = { it.id }) { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val (badgeBg, badgeText, badgeColor) = when (log.actionType) {
                                        "PEMASANGAN" -> Triple(Color(0xFF1E3A20), "Pemasangan Part", Color(0xFFA6D3A0))
                                        "PENGGANTIAN" -> Triple(Color(0xFF352E46), "Penggantian Part", Color(0xFFD0BCFF))
                                        "PELEPASAN" -> Triple(Color(0xFF3B2222), "Pelepasan Part", Color(0xFFFFB4AB))
                                        else -> Triple(Color(0xFF3B2E1E), log.actionType, Color(0xFFFFD59E))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeBg)
                                            .border(1.dp, badgeColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(badgeText, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = badgeColor)
                                    }

                                    Text(
                                        text = dateFormat.format(Date(log.date)),
                                        fontSize = 11.sp,
                                        color = Color(0xFF938F99)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = log.partName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE6E1E5)
                                )

                                if (log.partBarcode != "-") {
                                    Text(
                                        text = "Barcode: ${log.partBarcode}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFFCAC4D0)
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Odometer Servis: ${numberFormat.format(log.odometer)} KM • Teknisi: ${log.technicianName}",
                                    fontSize = 11.sp,
                                    color = Color(0xFFCAC4D0)
                                )

                                if (log.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Catatan: ${log.notes}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF938F99),
                                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun InstalledPartDetailCard(
    installedPart: InstalledPart,
    currentOdo: Int,
    onReplace: () -> Unit,
    onUpdateCondition: (String) -> Unit,
    onUninstall: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var showConditionMenu by remember { mutableStateOf(false) }
    var showUninstallDialog by remember { mutableStateOf(false) }

    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))
    val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("installed_part_card_${installedPart.partBarcode}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Category + Condition Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CategoryBadge(category = installedPart.partCategory)
                Box {
                    Surface(
                        modifier = Modifier.clickable { showConditionMenu = true },
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Transparent
                    ) {
                        ConditionBadge(condition = installedPart.conditionStatus)
                    }

                    DropdownMenu(
                        expanded = showConditionMenu,
                        onDismissRequest = { showConditionMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Bagus / Prima") },
                            onClick = {
                                onUpdateCondition("Bagus / Prima")
                                showConditionMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Normal") },
                            onClick = {
                                onUpdateCondition("Normal")
                                showConditionMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Perlu Pengecekan") },
                            onClick = {
                                onUpdateCondition("Perlu Pengecekan")
                                showConditionMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Aus / Segera Ganti") },
                            onClick = {
                                onUpdateCondition("Aus / Segera Ganti")
                                showConditionMenu = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Part Name
            Text(
                text = installedPart.partName,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Barcode & SKU
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = null,
                    tint = Color(0xFFCAC4D0),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${installedPart.partBarcode} (${installedPart.partSku})",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFCAC4D0)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Posisi Pemasangan
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF211F26),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF36343B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Posisi: ${installedPart.installationPosition}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFE6E1E5)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Health / Wear Progress Bar
            HealthProgressBar(
                installedOdo = installedPart.installedOdometer,
                currentOdo = currentOdo,
                targetIntervalKm = installedPart.targetOdometerInterval
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Meta: Tanggal pasang, KM pasang, Teknisi
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Dipasang: ${dateFormat.format(Date(installedPart.installedDate))} (KM ${numberFormat.format(installedPart.installedOdometer)})",
                    fontSize = 10.sp,
                    color = Color(0xFF938F99)
                )
                Text(
                    text = "Oleh: ${installedPart.technicianName}",
                    fontSize = 10.sp,
                    color = Color(0xFF938F99)
                )
            }

            if (installedPart.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Catatan: ${installedPart.notes}",
                    fontSize = 11.sp,
                    color = Color(0xFFCAC4D0),
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Ganti Part (Replace), Ubah Status, Lepas (Uninstall)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { showUninstallDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("Lepas", fontSize = 11.sp, color = Color(0xFFFFB4AB))
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onReplace,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0BCFF),
                        contentColor = Color(0xFF381E72)
                    ),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("replace_part_button_${installedPart.partBarcode}")
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Ganti Baru", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showUninstallDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showUninstallDialog = false },
            title = { Text("Lepas Komponen dari Bus") },
            text = {
                Text("Apakah Anda ingin melepas komponen '${installedPart.partName}' dari bus ini? Pilih apakah stok akan dikembalikan ke gudang atau part diafkir/rusak.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUninstall(true) // Return to stock
                        showUninstallDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0BCFF),
                        contentColor = Color(0xFF381E72)
                    )
                ) {
                    Text("Kembalikan ke Gudang")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        onUninstall(false) // Do not return to stock (scrap)
                        showUninstallDialog = false
                    },
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Text("Part Rusak / Afkir", color = Color(0xFFFFB4AB))
                }
            }
        )
    }
}
