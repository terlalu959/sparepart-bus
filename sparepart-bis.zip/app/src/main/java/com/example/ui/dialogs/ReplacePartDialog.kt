package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.SparePart
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReplacePartDialog(
    installedPart: InstalledPart,
    bus: BusUnit,
    allParts: List<SparePart>,
    onDismiss: () -> Unit,
    onConfirm: (InstalledPart, BusUnit, SparePart, Int, String, String, Int, String) -> Unit
) {
    // Find matching part in warehouse catalog as default
    val matchingPart = allParts.find { it.id == installedPart.sparePartId } ?: allParts.firstOrNull()
    var selectedNewPart by remember { mutableStateOf(matchingPart) }
    var partExpanded by remember { mutableStateOf(false) }

    var quantity by remember { mutableStateOf(installedPart.quantityInstalled.toString()) }
    var position by remember { mutableStateOf(installedPart.installationPosition) }
    var technician by remember { mutableStateOf("Joko (Teknisi Mesin)") }
    var targetIntervalKm by remember { mutableStateOf(installedPart.targetOdometerInterval.toString()) }
    var notes by remember { mutableStateOf("Penggantian komponen berkala / habis masa pakai") }

    val numberFormat = NumberFormat.getNumberInstance(Locale("id", "ID"))
    val kmTraveled = (bus.currentOdometer - installedPart.installedOdometer).coerceAtLeast(0)

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = { Text("Ganti Komponen Terpasang", fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5)) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Summary of old part
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF3B2222),
                    border = BorderStroke(1.dp, Color(0xFF8C1D18)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Part Lama Yang Diganti:",
                            fontSize = 11.sp,
                            color = Color(0xFFFFB4AB),
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${installedPart.partName} (${installedPart.partBarcode})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE6E1E5)
                        )
                        Text(
                            text = "Unit: ${bus.fleetNumber} (${bus.plateNumber}) • Posisi: ${installedPart.installationPosition}",
                            fontSize = 11.sp,
                            color = Color(0xFFCAC4D0)
                        )
                        Text(
                            text = "Total KM Terpakai: ${numberFormat.format(kmTraveled)} KM (dari target ${numberFormat.format(installedPart.targetOdometerInterval)} KM)",
                            fontSize = 11.sp,
                            color = Color(0xFFD0BCFF),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // New Part Selector
                ExposedDropdownMenuBox(
                    expanded = partExpanded,
                    onExpandedChange = { partExpanded = !partExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedNewPart?.let { "${it.name} - [Stok: ${it.stockQuantity} ${it.unit}]" } ?: "Pilih Part Pengganti",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Part Baru dari Gudang *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = partExpanded) },
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = partExpanded,
                        onDismissRequest = { partExpanded = false },
                        containerColor = Color(0xFF2B2930)
                    ) {
                        allParts.forEach { part ->
                            DropdownMenuItem(
                                text = { Text("${part.name} (Stok: ${part.stockQuantity} ${part.unit})", color = Color(0xFFE6E1E5)) },
                                onClick = {
                                    selectedNewPart = part
                                    partExpanded = false
                                },
                                colors = MenuDefaults.itemColors(textColor = Color(0xFFE6E1E5))
                            )
                        }
                    }
                }

                // Position & Quantity
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = position,
                        onValueChange = { position = it },
                        label = { Text("Posisi Pasang") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1.5f)
                    )
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Jumlah") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Target KM Interval
                OutlinedTextField(
                    value = targetIntervalKm,
                    onValueChange = { targetIntervalKm = it },
                    label = { Text("Target Pakai Part Baru (KM)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Technician
                OutlinedTextField(
                    value = technician,
                    onValueChange = { technician = it },
                    label = { Text("Nama Teknisi") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Servis / Penggantian") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedNewPart != null) {
                        onConfirm(
                            installedPart,
                            bus,
                            selectedNewPart!!,
                            quantity.toIntOrNull() ?: 1,
                            position.trim(),
                            technician.trim(),
                            targetIntervalKm.toIntOrNull() ?: 20000,
                            notes.trim()
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("confirm_replace_button")
            ) {
                Text("Konfirmasi Penggantian", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
