package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SparePart

@Composable
fun AdjustStockDialog(
    part: SparePart,
    onDismiss: () -> Unit,
    onConfirm: (Int, String) -> Unit
) {
    var isAddition by remember { mutableStateOf(true) }
    var quantityText by remember { mutableStateOf("5") }
    var reason by remember { mutableStateOf("Pengadaan baru supplier") }

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = { Text("Penyesuaian Stok Gudang", fontWeight = FontWeight.Bold, color = Color(0xFFE6E1E5)) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = part.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFFD0BCFF)
                )
                Text(
                    text = "Stok Saat Ini: ${part.stockQuantity} ${part.unit} (Lokasi: ${part.rackLocation})",
                    fontSize = 12.sp,
                    color = Color(0xFFCAC4D0)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Mode Selector: Tambah / Kurangi
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isAddition,
                        onClick = {
                            isAddition = true
                            reason = "Pengadaan baru supplier"
                        },
                        label = { Text("+ Tambah Stok (In)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF1E3A20),
                            selectedLabelColor = Color(0xFFA6D3A0),
                            containerColor = Color(0xFF1C1B1F),
                            labelColor = Color(0xFFCAC4D0)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isAddition,
                            borderColor = if (isAddition) Color(0xFFA6D3A0) else Color(0xFF49454F)
                        )
                    )
                    FilterChip(
                        selected = !isAddition,
                        onClick = {
                            isAddition = false
                            reason = "Penyesuaian stok opname / rusak"
                        },
                        label = { Text("- Kurangi Stok (Out)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF3B2222),
                            selectedLabelColor = Color(0xFFFFB4AB),
                            containerColor = Color(0xFF1C1B1F),
                            labelColor = Color(0xFFCAC4D0)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = !isAddition,
                            borderColor = if (!isAddition) Color(0xFFFFB4AB) else Color(0xFF49454F)
                        )
                    )
                }

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Jumlah ${part.unit}") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("adjust_stock_qty_input")
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Alasan Penyesuaian") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toIntOrNull() ?: 0
                    if (qty > 0) {
                        val delta = if (isAddition) qty else -qty
                        onConfirm(delta, reason)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("confirm_adjust_stock_button")
            ) {
                Text("Simpan Penyesuaian", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
