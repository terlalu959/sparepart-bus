package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SparePart
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSparePartDialog(
    initialPart: SparePart? = null,
    initialBarcode: String = "",
    onDismiss: () -> Unit,
    onSave: (SparePart) -> Unit
) {
    var name by remember { mutableStateOf(initialPart?.name ?: "") }
    var sku by remember { mutableStateOf(initialPart?.sku ?: "PRT-${Random.nextInt(100, 999)}") }
    var barcode by remember {
        mutableStateOf(
            if (initialPart != null) initialPart.barcode
            else if (initialBarcode.isNotBlank()) initialBarcode
            else "89927750${Random.nextInt(1000, 9999)}"
        )
    }
    var category by remember { mutableStateOf(initialPart?.category ?: "Mesin") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var brand by remember { mutableStateOf(initialPart?.brand ?: "") }
    var stockQuantity by remember { mutableStateOf(initialPart?.stockQuantity?.toString() ?: "10") }
    var minStockThreshold by remember { mutableStateOf(initialPart?.minStockThreshold?.toString() ?: "3") }
    var unit by remember { mutableStateOf(initialPart?.unit ?: "Pcs") }
    var rackLocation by remember { mutableStateOf(initialPart?.rackLocation ?: "Rak A-01") }
    var price by remember { mutableStateOf(if (initialPart != null && initialPart.price > 0) initialPart.price.toInt().toString() else "250000") }
    var specifications by remember { mutableStateOf(initialPart?.specifications ?: "") }
    var compatibleBusModels by remember { mutableStateOf(initialPart?.compatibleBusModels ?: "Hino RK8, Mercedes OH 1626, Scania K360IB") }

    val categories = listOf("Mesin", "Pengereman", "Suspensi", "Filter", "Pelumas", "Kelistrikan", "Transmisi", "Body")

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFE6E1E5),
        unfocusedTextColor = Color(0xFFE6E1E5),
        focusedBorderColor = Color(0xFFD0BCFF),
        unfocusedBorderColor = Color(0xFF49454F),
        focusedLabelColor = Color(0xFFD0BCFF),
        unfocusedLabelColor = Color(0xFFCAC4D0),
        focusedPlaceholderColor = Color(0xFF938F99),
        unfocusedPlaceholderColor = Color(0xFF938F99),
        focusedContainerColor = Color(0xFF1C1B1F),
        unfocusedContainerColor = Color(0xFF1C1B1F)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2930),
        titleContentColor = Color(0xFFE6E1E5),
        textContentColor = Color(0xFFCAC4D0),
        title = {
            Text(
                if (initialPart == null) "Tambah Sparepart Baru" else "Edit Data Sparepart",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Sparepart *") },
                    placeholder = { Text("Contoh: Filter Oli Mesin J08E") },
                    singleLine = true,
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("part_name_input")
                )

                // Barcode Field with Random Generator Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text("Kode Barcode *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("part_barcode_input")
                    )
                    IconButton(
                        onClick = { barcode = "89927750${Random.nextInt(1000, 9999)}" },
                        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Autorenew, contentDescription = "Generate Barcode", tint = Color(0xFFD0BCFF))
                    }
                }

                // SKU & Brand
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("Kode SKU") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = brand,
                        onValueChange = { brand = it },
                        label = { Text("Merk / Brand") },
                        placeholder = { Text("Hino / Bendix") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Category Dropdown
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Kategori Part") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        containerColor = Color(0xFF2B2930)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, color = Color(0xFFE6E1E5)) },
                                onClick = {
                                    category = cat
                                    categoryExpanded = false
                                },
                                colors = MenuDefaults.itemColors(
                                    textColor = Color(0xFFE6E1E5)
                                )
                            )
                        }
                    }
                }

                // Stock Quantity, Min Threshold, Unit
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockQuantity,
                        onValueChange = { stockQuantity = it },
                        label = { Text("Stok Awal") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minStockThreshold,
                        onValueChange = { minStockThreshold = it },
                        label = { Text("Batas Kritis") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = unit,
                        onValueChange = { unit = it },
                        label = { Text("Satuan") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Price & Rack Location
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = price,
                        onValueChange = { price = it },
                        label = { Text("Harga Satuan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = rackLocation,
                        onValueChange = { rackLocation = it },
                        label = { Text("Lokasi Gudang / Rak") },
                        singleLine = true,
                        colors = textFieldColors,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Compatible Bus Models
                OutlinedTextField(
                    value = compatibleBusModels,
                    onValueChange = { compatibleBusModels = it },
                    label = { Text("Kesesuaian Tipe / Model Bus") },
                    placeholder = { Text("Contoh: Hino RK8, Mercy 1626, Scania K360") },
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Specifications
                OutlinedTextField(
                    value = specifications,
                    onValueChange = { specifications = it },
                    label = { Text("Spesifikasi Teknis / Catatan") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = textFieldColors,
                    shape = RoundedCornerShape(10.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && barcode.isNotBlank()) {
                        val part = SparePart(
                            id = initialPart?.id ?: 0L,
                            sku = sku.ifBlank { "PRT-${Random.nextInt(100, 999)}" },
                            barcode = barcode.trim(),
                            name = name.trim(),
                            category = category,
                            brand = brand.ifBlank { "Universal" },
                            stockQuantity = stockQuantity.toIntOrNull() ?: 0,
                            minStockThreshold = minStockThreshold.toIntOrNull() ?: 3,
                            unit = unit.ifBlank { "Pcs" },
                            rackLocation = rackLocation.ifBlank { "Gudang Utama" },
                            price = price.toDoubleOrNull() ?: 0.0,
                            specifications = specifications,
                            compatibleBusModels = compatibleBusModels.ifBlank { "Semua Tipe Bus" },
                            createdAt = initialPart?.createdAt ?: System.currentTimeMillis()
                        )
                        onSave(part)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD0BCFF),
                    contentColor = Color(0xFF381E72)
                ),
                modifier = Modifier.testTag("save_spare_part_button")
            ) {
                Text("Simpan", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCAC4D0))
            ) {
                Text("Batal")
            }
        }
    )
}
