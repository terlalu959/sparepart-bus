package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusUnit
import com.example.data.model.InstalledPart
import com.example.data.model.MaintenanceLog
import com.example.data.model.SparePart
import com.example.ui.components.BusStatusBadge
import com.example.ui.components.StockBadge
import com.example.ui.theme.BusAmber
import com.example.ui.theme.BusBlueLight
import com.example.ui.theme.BusBluePrimary
import com.example.ui.theme.BusEmerald
import com.example.ui.theme.BusRose
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onNavigateToScan: () -> Unit,
    onNavigateToParts: () -> Unit,
    onNavigateToBuses: () -> Unit,
    onOpenBusDetail: (Long) -> Unit,
    onAddPartClick: () -> Unit,
    onAddBusClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val buses by viewModel.allBuses.collectAsStateWithLifecycle()
    val parts by viewModel.allSpareParts.collectAsStateWithLifecycle()
    val installedParts by viewModel.allActiveInstalledParts.collectAsStateWithLifecycle()
    val logs by viewModel.allLogs.collectAsStateWithLifecycle()
    val lowStockParts by viewModel.lowStockParts.collectAsStateWithLifecycle()

    val operatingBusesCount = buses.count { it.operationalStatus == "Beroperasi" }
    val maintenanceBusesCount = buses.count { it.operationalStatus != "Beroperasi" }

    // Count installed parts that need attention (e.g. condition contains Aus/Pengecekan or km exceeded)
    val criticalInstalledParts = installedParts.filter { installed ->
        val bus = buses.find { it.id == installed.busId }
        val currentOdo = bus?.currentOdometer ?: 0
        val kmUsed = (currentOdo - installed.installedOdometer)
        val isExceeded = installed.targetOdometerInterval > 0 && kmUsed >= (installed.targetOdometerInterval * 0.85f)
        isExceeded || installed.conditionStatus.contains("Pengecekan") || installed.conditionStatus.contains("Aus")
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner with Barcode Scanner Callout
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_hero_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF2B2930), Color(0xFF211F26), Color(0xFF352E46))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "SISTEM MANAJEMEN SPAREPART",
                                    color = Color(0xFFD0BCFF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Armada & Barcode Tracking",
                                    color = Color(0xFFE6E1E5),
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFF4A4458),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsBus,
                                        contentDescription = null,
                                        tint = Color(0xFFD0BCFF),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Big Scan Action Button
                        Button(
                            onClick = onNavigateToScan,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("hero_scan_barcode_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD0BCFF),
                                contentColor = Color(0xFF381E72)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Scan Barcode Part Sekarang",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // KPI Summary Cards (2x2 Grid)
        item {
            Text(
                text = "Ringkasan Operasional",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Unit Armada",
                        value = "${buses.size} Bus",
                        subValue = "$operatingBusesCount Siap Jalan",
                        icon = Icons.Default.DirectionsBus,
                        iconBg = Color(0xFF352E46),
                        iconTint = Color(0xFFD0BCFF),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToBuses() }
                    )
                    KpiCard(
                        title = "Katalog Part",
                        value = "${parts.size} Item",
                        subValue = "${installedParts.size} Terpasang",
                        icon = Icons.Default.Inventory2,
                        iconBg = Color(0xFF1E3A20),
                        iconTint = Color(0xFFA6D3A0),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToParts() }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    KpiCard(
                        title = "Stok Kritis/Habis",
                        value = "${lowStockParts.size} Part",
                        subValue = if (lowStockParts.isEmpty()) "Semua Aman" else "Perlu Restock",
                        icon = Icons.Default.WarningAmber,
                        iconBg = if (lowStockParts.isNotEmpty()) Color(0xFF3B2222) else Color(0xFF2B2930),
                        iconTint = if (lowStockParts.isNotEmpty()) Color(0xFFFFB4AB) else Color(0xFFCAC4D0),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToParts() }
                    )
                    KpiCard(
                        title = "Perhatian Servis",
                        value = "${criticalInstalledParts.size} Part",
                        subValue = if (criticalInstalledParts.isEmpty()) "Kondisi Prima" else "Mendekati Batas KM",
                        icon = Icons.Default.Engineering,
                        iconBg = if (criticalInstalledParts.isNotEmpty()) Color(0xFF3B2E1E) else Color(0xFF2B2930),
                        iconTint = if (criticalInstalledParts.isNotEmpty()) Color(0xFFFFD59E) else Color(0xFFCAC4D0),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Actions Row
        item {
            Text(
                text = "Aksi Cepat",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onAddPartClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_part_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Sparepart", fontSize = 12.sp, maxLines = 1, color = Color(0xFFE6E1E5))
                }

                OutlinedButton(
                    onClick = onAddBusClick,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_bus_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Armada Bus", fontSize = 12.sp, maxLines = 1, color = Color(0xFFE6E1E5))
                }
            }
        }

        // Critical Parts Alert Section (If any)
        if (criticalInstalledParts.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFFFD59E),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Peringatan Komponen Terpasang",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE6E1E5)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    criticalInstalledParts.take(3).forEach { installed ->
                        val bus = buses.find { it.id == installed.busId }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (bus != null) onOpenBusDetail(bus.id)
                                },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF3B2E1E)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD59E).copy(alpha = 0.35f)),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = installed.partName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFFFFD59E)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Terpasang di: ${bus?.fleetNumber ?: "-"} (${bus?.plateNumber ?: "-"}) • Posisi: ${installed.installationPosition}",
                                        fontSize = 12.sp,
                                        color = Color(0xFFCAC4D0)
                                    )
                                    Text(
                                        text = "Status: ${installed.conditionStatus}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFFFB4AB)
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.Build,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD59E),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Activity / Maintenance Logs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Aktivitas Servis & Mutasi Terbaru",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE6E1E5)
                )
                Text(
                    text = "${logs.size} Riwayat",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFD0BCFF)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (logs.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Belum ada log mutasi atau servis",
                            color = Color(0xFF938F99),
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
                    logs.take(4).forEach { log ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val (badgeBg, badgeText, badgeColor) = when (log.actionType) {
                                    "PEMASANGAN" -> Triple(Color(0xFF1E3A20), "Pasang", Color(0xFFA6D3A0))
                                    "PENGGANTIAN" -> Triple(Color(0xFF352E46), "Ganti", Color(0xFFD0BCFF))
                                    "PELEPASAN" -> Triple(Color(0xFF3B2222), "Lepas", Color(0xFFFFB4AB))
                                    "RESTOCK" -> Triple(Color(0xFF3B2E1E), "Restock", Color(0xFFFFD59E))
                                    else -> Triple(Color(0xFF36343B), log.actionType, Color(0xFFCAC4D0))
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(badgeBg)
                                        .border(1.dp, badgeColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeColor
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = log.partName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFFE6E1E5)
                                    )
                                    Text(
                                        text = if (log.busFleetNumber != "-") "${log.busFleetNumber} (${log.busPlateNumber}) • Oleh: ${log.technicianName}" else "Gudang • Oleh: ${log.technicianName}",
                                        fontSize = 11.sp,
                                        color = Color(0xFFCAC4D0)
                                    )
                                    Text(
                                        text = dateFormat.format(Date(log.date)),
                                        fontSize = 10.sp,
                                        color = Color(0xFF938F99)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subValue: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2930)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color(0xFFCAC4D0),
                    fontWeight = FontWeight.Medium
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE6E1E5)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subValue,
                fontSize = 11.sp,
                color = Color(0xFF938F99)
            )
        }
    }
}
